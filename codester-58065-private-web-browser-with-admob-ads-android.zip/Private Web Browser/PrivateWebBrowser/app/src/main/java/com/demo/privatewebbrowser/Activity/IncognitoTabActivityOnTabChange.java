package com.demo.privatewebbrowser.Activity;

import com.demo.privatewebbrowser.Adapter.IncognitoTabAdapter;


public final class IncognitoTabActivityOnTabChange implements IncognitoTabAdapter.OnTabChange {
    public final IncognitoTabActivity act1;

    public IncognitoTabActivityOnTabChange(IncognitoTabActivity incognitoTabActivity) {
        this.act1 = incognitoTabActivity;
    }

    @Override
    public void changed() {
        this.act1.IncognitoTabActivityOnTabChangeCall();
    }
}
