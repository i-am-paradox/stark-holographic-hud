package com.demo.privatewebbrowser.Activity;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.demo.privatewebbrowser.R;
import com.demo.privatewebbrowser.UtilsSaveData.SearchPref;
import com.demo.privatewebbrowser.ads.AdsCommon;
import com.demo.privatewebbrowser.ads.MyApplication;
import com.facebook.ads.NativeAdLayout;


public class SettingActivity extends AppCompatActivity {
    private SearchPref.Engine chosen;
    ImageView imgBing;
    ImageView imgDuckGo;
    ImageView imgGoogle;
    ImageView imgYahoo;
    LinearLayout llBing;
    LinearLayout llDuckDuckgo;
    LinearLayout llGoogle;
    LinearLayout llYahoo;
    SwitchCompat switchON;
    TextView txtEngine;
    TextView txtON;

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        setContentView(R.layout.activity_setting);

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) findViewById(R.id.Admob_Banner_Frame);
        LinearLayout adContainer = (LinearLayout) findViewById(R.id.banner_container);
        FrameLayout qureka = (FrameLayout) findViewById(R.id.qureka);
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);

        //Reguler Native Ads
        FrameLayout admob_native_frame = (FrameLayout) findViewById(R.id.Admob_Native_Frame);
        NativeAdLayout nativeAdLayout = (NativeAdLayout) findViewById(R.id.native_ad_container);
        FrameLayout maxNative = (FrameLayout) findViewById(R.id.max_native_ad_layout);
        AdsCommon.RegulerBigNative(this, admob_native_frame, nativeAdLayout, maxNative);


        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(1024);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.black));
        WindowCompat.setDecorFitsSystemWindows(window, true);



        this.txtEngine = (TextView) findViewById(R.id.txtEngine);
        SwitchCompat switchCompat = (SwitchCompat) findViewById(R.id.switchON);
        this.switchON = switchCompat;
        switchCompat.setThumbTintList(ContextCompat.getColorStateList(this, R.color.switch_thumb_color));
        this.switchON.setTrackTintList(ContextCompat.getColorStateList(this, R.color.switch_track_color));
        SharedPreferences sharedPreferences2 = getSharedPreferences(SearchPref.PREF_NAME, 0);
        this.switchON.setChecked(sharedPreferences2.getBoolean(SearchPref.KEY_AUTO_SUGGEST, true));
        this.switchON.setOnCheckedChangeListener(new SettingActivityCompoundButton(this, sharedPreferences2));
        this.txtEngine.setText(getEngineDisplayName(SearchPref.Engine.fromId(getSharedPreferences(SearchPref.PREF_NAME, 0).getString(SearchPref.KEY_ENGINE, SearchPref.Engine.GOOGLE.id))));
        findViewById(R.id.imgBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        findViewById(R.id.rlGeneral).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SettingActivity.this.showEngineDialog();
            }
        });
        findViewById(R.id.rlDownload).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SettingActivity.this.startActivity(new Intent("android.intent.action.VIEW_DOWNLOADS"));
            }
        });
        findViewById(R.id.rlPolicy).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentPrivacy = new Intent(Intent.ACTION_VIEW, Uri.parse(MyApplication.PrivacyPolicy));
                intentPrivacy.setPackage("com.android.chrome");
                startActivity(intentPrivacy);
            }
        });
    }

    
    public void SettingActivityCompoundButtonCall(SharedPreferences sharedPreferences, CompoundButton compoundButton, boolean z) {
        sharedPreferences.edit().putBoolean(SearchPref.KEY_AUTO_SUGGEST, z).apply();
        Toast.makeText(this, "Auto-suggest turned ".concat(z ? "ON" : "OFF"), Toast.LENGTH_SHORT).show();
    }

    
    public void showEngineDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.search_engine_dialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        this.llGoogle = (LinearLayout) dialog.findViewById(R.id.llGoogle);
        this.llDuckDuckgo = (LinearLayout) dialog.findViewById(R.id.llDuckDuckgo);
        this.llBing = (LinearLayout) dialog.findViewById(R.id.llBing);
        this.llYahoo = (LinearLayout) dialog.findViewById(R.id.llYahoo);
        this.imgGoogle = (ImageView) dialog.findViewById(R.id.imgGoogle);
        this.imgDuckGo = (ImageView) dialog.findViewById(R.id.imgDuckGo);
        this.imgBing = (ImageView) dialog.findViewById(R.id.imgBing);
        this.imgYahoo = (ImageView) dialog.findViewById(R.id.imgYahoo);
        SharedPreferences sharedPreferences = getSharedPreferences(SearchPref.PREF_NAME, 0);
        this.chosen = SearchPref.Engine.fromId(sharedPreferences.getString(SearchPref.KEY_ENGINE, SearchPref.Engine.GOOGLE.id));
        updateIcons();
        this.llGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chosen = SearchPref.Engine.GOOGLE;
                updateIcons();
            }
        });
        this.llDuckDuckgo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chosen = SearchPref.Engine.DUCKDUCKGO;
                updateIcons();
            }
        });
        this.llBing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chosen = SearchPref.Engine.BING;
                updateIcons();
            }
        });
        this.llYahoo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chosen = SearchPref.Engine.YAHOO;
                updateIcons();
            }
        });
        ((TextView) dialog.findViewById(R.id.txtOK)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sharedPreferences.edit().putString(SearchPref.KEY_ENGINE, chosen.id).apply();
                txtEngine.setText(getEngineDisplayName(chosen));
                dialog.dismiss();
                Toast.makeText(SettingActivity.this, "Search engine changed to " + chosen.name(), Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    static class ClassWEB5 {
        static final int[] UtilsSaveDataSearchPrefEngine;

        static {
            int[] iArr = new int[SearchPref.Engine.values().length];
            UtilsSaveDataSearchPrefEngine = iArr;
            iArr[SearchPref.Engine.GOOGLE.ordinal()] = 1;
            UtilsSaveDataSearchPrefEngine[SearchPref.Engine.DUCKDUCKGO.ordinal()] = 2;
            UtilsSaveDataSearchPrefEngine[SearchPref.Engine.BING.ordinal()] = 3;
            try {
                UtilsSaveDataSearchPrefEngine[SearchPref.Engine.YAHOO.ordinal()] = 4;
            } catch (NoSuchFieldError unused) {
            }
        }
    }

    private String getEngineDisplayName(SearchPref.Engine engine) {
        int i = ClassWEB5.UtilsSaveDataSearchPrefEngine[engine.ordinal()];
        if (i == 2) {
            return "DuckDuckGo";
        }
        if (i == 3) {
            return "Bing";
        }
        if (i != 4) {
            return "Google";
        }
        return "Yahoo";
    }

    private void updateIcons() {
        this.imgGoogle.setImageResource(this.chosen == SearchPref.Engine.GOOGLE ? R.drawable.ic_select : R.drawable.ic_unselect);
        this.imgDuckGo.setImageResource(this.chosen == SearchPref.Engine.DUCKDUCKGO ? R.drawable.ic_select : R.drawable.ic_unselect);
        this.imgBing.setImageResource(this.chosen == SearchPref.Engine.BING ? R.drawable.ic_select : R.drawable.ic_unselect);
        this.imgYahoo.setImageResource(this.chosen == SearchPref.Engine.YAHOO ? R.drawable.ic_select : R.drawable.ic_unselect);
    }
}
