package com.demo.privatewebbrowser.Activity;

import android.app.Dialog;
import android.app.DownloadManager;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.demo.privatewebbrowser.Adapter.DownloadAdapter;
import com.demo.privatewebbrowser.Model.DownloadItem;
import com.demo.privatewebbrowser.R;
import com.demo.privatewebbrowser.ads.AdsCommon;

import java.util.ArrayList;
import java.util.List;

public class DownloadActivity extends AppCompatActivity {

    private DownloadAdapter adapter;
    private DownloadManager dm;
    ImageView imgDelete;
    private final List<DownloadItem> items = new ArrayList();
    LinearLayout llNoData;
    private RecyclerView rvDownload;
    TextView txtNoData;

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        setContentView(R.layout.activity_download);

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) findViewById(R.id.Admob_Banner_Frame);
        LinearLayout adContainer = (LinearLayout) findViewById(R.id.banner_container);
        FrameLayout qureka = (FrameLayout) findViewById(R.id.qureka);
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(1024);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.black));
        WindowCompat.setDecorFitsSystemWindows(window, true);

        this.rvDownload = (RecyclerView) findViewById(R.id.rvDownload);
        this.txtNoData = (TextView) findViewById(R.id.txtNoData);
        this.imgDelete = (ImageView) findViewById(R.id.imgDelete);
        this.llNoData = (LinearLayout) findViewById(R.id.llNoData);
        this.rvDownload.setLayoutManager(new LinearLayoutManager(this));
        DownloadAdapter downloadAdapter = new DownloadAdapter(this, this.items);
        this.adapter = downloadAdapter;
        this.rvDownload.setAdapter(downloadAdapter);
        this.dm = (DownloadManager) getSystemService("download");
        loadFromPrefs();
        queryStatuses();
        updateEmptyState();
        findViewById(R.id.imgBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        this.imgDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showClearDialog();
            }
        });
    }

    private void showClearDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.delete_history_layout);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().setLayout(-1, -1);
            dialog.getWindow().setGravity(17);
        }
        ((TextView) dialog.findViewById(R.id.txtTitle)).setText("Clear Download");
        ((TextView) dialog.findViewById(R.id.txtData)).setText("Would you like to clear all download \ndata?");
        ((TextView) dialog.findViewById(R.id.txtNo)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        ((TextView) dialog.findViewById(R.id.txtYes)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSharedPreferences("downloads", 0).edit().clear().apply();
                items.clear();
                adapter.notifyDataSetChanged();
                updateEmptyState();
                Toast.makeText(DownloadActivity.this, "Download cleared..", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void updateEmptyState() {
        if (this.adapter.getItemCount() == 0) {
            this.llNoData.setVisibility(View.VISIBLE);
            this.rvDownload.setVisibility(View.GONE);
            this.imgDelete.setVisibility(View.GONE);
            return;
        }
        this.llNoData.setVisibility(View.GONE);
        this.rvDownload.setVisibility(View.VISIBLE);
        this.imgDelete.setVisibility(View.VISIBLE);
    }

    private void queryStatuses() {
        if (this.items.isEmpty()) {
            this.adapter.notifyDataSetChanged();
            updateEmptyState();
            return;
        }
        DownloadManager.Query query = new DownloadManager.Query();
        long[] jArr = new long[this.items.size()];
        for (int i = 0; i < this.items.size(); i++) {
            jArr[i] = this.items.get(i).id;
        }
        query.setFilterById(jArr);
        Cursor query2 = this.dm.query(query);
        while (query2.moveToNext()) {
            try {
                DownloadItem find = find(query2.getLong(query2.getColumnIndexOrThrow("_id")));
                find.title = query2.getString(query2.getColumnIndexOrThrow("title"));
                find.status = query2.getInt(query2.getColumnIndexOrThrow("status"));
                find.localUri = query2.getString(query2.getColumnIndexOrThrow("local_uri"));
                long j = query2.getLong(query2.getColumnIndexOrThrow("total_size"));
                find.progress = j > 0 ? (int) ((query2.getLong(query2.getColumnIndexOrThrow("bytes_so_far")) * 100) / j) : -1;
            } catch (Throwable th) {
                th.addSuppressed(th);
            }
        }
        if (query2 != null) {
            query2.close();
        }
        DownloadAdapter downloadAdapter = this.adapter;
        if (downloadAdapter != null) {
            downloadAdapter.notifyDataSetChanged();
        }
        this.dm.query(new DownloadManager.Query().setFilterByStatus(6)).getCount();
        return;
    }

    private DownloadItem find(long j) {
        for (DownloadItem next : this.items) {
            if (next.id == j) {
                return next;
            }
        }
        DownloadItem downloadItem = new DownloadItem(j);
        this.items.add(downloadItem);
        return downloadItem;
    }

    private void loadFromPrefs() {
        for (String parseLong : getSharedPreferences("downloads", 0).getAll().keySet()) {
            try {
                long parseLong2 = Long.parseLong(parseLong);
                if (find(parseLong2) == null) {
                    this.items.add(new DownloadItem(parseLong2));
                }
            } catch (NumberFormatException unused) {
            }
        }
    }
}
