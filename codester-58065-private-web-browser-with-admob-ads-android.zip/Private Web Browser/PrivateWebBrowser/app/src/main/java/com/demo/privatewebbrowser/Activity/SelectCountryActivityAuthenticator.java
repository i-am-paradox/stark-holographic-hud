package com.demo.privatewebbrowser.Activity;

import com.demo.privatewebbrowser.Model.ProxyData;
import okhttp3.Authenticator;
import okhttp3.Credentials;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;


public final class SelectCountryActivityAuthenticator implements Authenticator {
    public final ProxyData pd1;

    public SelectCountryActivityAuthenticator(ProxyData proxyData) {
        this.pd1 = proxyData;
    }

    @Override
    public Request authenticate(Route route, Response response) {
        return response.request().newBuilder().header("Proxy-Authorization", Credentials.basic(this.pd1.user, this.pd1.pass)).build();
    }
}
