package com.demo.privatewebbrowser.Activity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.demo.privatewebbrowser.Adapter.TabAdapter;
import com.demo.privatewebbrowser.R;
import com.demo.privatewebbrowser.UtilsSaveData.TabManager;
import com.demo.privatewebbrowser.ads.AdsCommon;

public class TabOpenActivity extends AppCompatActivity {
    private TabAdapter adapter;

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        setContentView(R.layout.activity_tab_open);

        applyDisplayCutouts();


        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) findViewById(R.id.Admob_Banner_Frame);
        LinearLayout adContainer = (LinearLayout) findViewById(R.id.banner_container);
        FrameLayout qureka = (FrameLayout) findViewById(R.id.qureka);
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(1024);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.black));
        WindowCompat.setDecorFitsSystemWindows(window, true);

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rvTab);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        TabAdapter tabAdapter = new TabAdapter(new TabOpenActivityOnCardClick(this), new TabOpenActivityOnTabChange(this));
        this.adapter = tabAdapter;
        recyclerView.setAdapter(tabAdapter);
        ((ImageView) findViewById(R.id.imgAddTab)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TabManager.addTab();
                adapter.refresh();
                setResultAndFinish(TabManager.current());
                recyclerView.scrollToPosition(TabManager.size() - 1);
            }
        });
        findViewById(R.id.imgBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    
    public void TabOpenActivityOnTabChangeCall() {
        setResultAndFinish(TabManager.current());
    }

    private void setResultAndFinish(int i) {
        setResult(-1, new Intent().putExtra("tab", i));
        finish();
    }

    
    public void returnChoice(int i) {
        setResult(-1, new Intent().putExtra("tab", i));
        finish();
    }

    @Override
    public void onResume() {
        super.onResume();
        this.adapter.refresh();
        this.adapter.notifyDataSetChanged();
    }

}
