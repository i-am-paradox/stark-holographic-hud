package com.demo.privatewebbrowser.Activity;

import java.util.function.Consumer;


public final class SelectCountryActivityConsumer1 implements Consumer {
    public final SelectCountryActivity act1;
    public final int int1;

    public SelectCountryActivityConsumer1(SelectCountryActivity selectCountryActivity, int i) {
        this.act1 = selectCountryActivity;
        this.int1 = i;
    }

    @Override
    public void accept(Object obj) {
        this.act1.SelectCountryActivityConsumer1Call(this.int1, (Boolean) obj);
    }
}
