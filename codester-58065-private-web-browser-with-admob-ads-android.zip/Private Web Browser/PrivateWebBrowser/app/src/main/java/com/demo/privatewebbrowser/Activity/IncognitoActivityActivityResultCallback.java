package com.demo.privatewebbrowser.Activity;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;


public final class IncognitoActivityActivityResultCallback implements ActivityResultCallback {
    public final IncognitoActivity act1;

    public IncognitoActivityActivityResultCallback(IncognitoActivity incognitoActivity) {
        this.act1 = incognitoActivity;
    }

    @Override
    public void onActivityResult(Object obj) {
        this.act1.IncognitoActivityActivityResultCallbackCall((ActivityResult) obj);
    }
}
