package com.demo.privatewebbrowser.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.demo.privatewebbrowser.Activity.HistoryActivity;
import com.demo.privatewebbrowser.Activity.HomeBrowserActivity;
import com.demo.privatewebbrowser.Model.HistoryItem;
import com.demo.privatewebbrowser.R;
import com.demo.privatewebbrowser.UtilsSaveData.HistoryStore;
import com.demo.privatewebbrowser.UtilsSaveData.TabManager;
import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {
    Context context;
    private final List<HistoryItem> data;

    public HistoryAdapter(Context context2, List<HistoryItem> list) {
        this.context = context2;
        this.data = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_history, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        HistoryItem historyItem = this.data.get(i);
        viewHolder.txtTitle.setText(historyItem.title);
        viewHolder.txtUrl.setText(historyItem.url);
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, HomeBrowserActivity.class);
                intent.putExtra("history_url", historyItem.url);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
        viewHolder.imgDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgDeleteCall(viewHolder, v);
            }
        });

    }

    
    public void imgDeleteCall(ViewHolder viewHolder, View view) {
        int adapterPosition = viewHolder.getAdapterPosition();
        if (adapterPosition != -1) {
            HistoryItem historyItem = this.data.get(adapterPosition);
            HistoryStore.remove(this.context, historyItem.url);
            int i = 0;
            while (true) {
                if (i >= TabManager.size()) {
                    break;
                }
                TabManager.Tab tab = TabManager.get(i);
                if (tab.url != null && tab.url.equals(historyItem.url)) {
                    TabManager.close(i);
                    break;
                }
                i++;
            }
            this.data.remove(adapterPosition);
            notifyItemRemoved(adapterPosition);
            Context context2 = this.context;
            if (context2 instanceof HistoryActivity) {
                ((HistoryActivity) context2).updateEmptyState();
            }
        }
    }

    @Override
    public int getItemCount() {
        return this.data.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgDelete;
        TextView txtTitle;
        TextView txtUrl;

        ViewHolder(View view) {
            super(view);
            this.txtTitle = (TextView) view.findViewById(R.id.txtTitle);
            this.txtUrl = (TextView) view.findViewById(R.id.txtUrl);
            this.imgDelete = (ImageView) view.findViewById(R.id.imgDelete);
        }
    }

    public void updateData(List<HistoryItem> list) {
        this.data.clear();
        this.data.addAll(list);
        notifyDataSetChanged();
    }
}
