package com.demo.privatewebbrowser.Activity;

import com.demo.privatewebbrowser.Adapter.TabAdapter;


public final class TabOpenActivityOnTabChange implements TabAdapter.OnTabChange {
    public final TabOpenActivity act1;

    public TabOpenActivityOnTabChange(TabOpenActivity tabOpenActivity) {
        this.act1 = tabOpenActivity;
    }

    @Override
    public void changed() {
        this.act1.TabOpenActivityOnTabChangeCall();
    }
}
