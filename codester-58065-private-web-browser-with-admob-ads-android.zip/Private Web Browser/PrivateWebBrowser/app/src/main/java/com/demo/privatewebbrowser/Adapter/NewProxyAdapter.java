package com.demo.privatewebbrowser.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.demo.privatewebbrowser.Model.ProxyData;
import com.demo.privatewebbrowser.R;
import com.demo.privatewebbrowser.UtilsSaveData.CountryResolver;
import java.util.List;

public class NewProxyAdapter extends RecyclerView.Adapter<NewProxyAdapter.ViewHolder> {
    private final OnProxyClick cb;
    private final List<ProxyData> data;
    private int selected;

    public interface OnProxyClick {
        void onClick(ProxyData proxyData, int i);
    }

    public NewProxyAdapter(List<ProxyData> list, int i, OnProxyClick onProxyClick) {
        this.data = list;
        this.selected = i;
        this.cb = onProxyClick;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.data_itemproxy, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        ProxyData proxyData = this.data.get(i);
        viewHolder.tvCountry.setText(proxyData.noProxy ? "Quality :" : "high");
        if (proxyData.country == null || proxyData.countryCode == null) {
            viewHolder.tvCountry.setText("Fetching...");
            viewHolder.imgFlag.setImageResource(R.drawable.logo);
            CountryResolver.fetchCountryFromIP(proxyData.host, new CountryResolver.OnCountryResolved() {
                @Override
                public void onResult(String str, String str2) {
                    proxyData.country = str;
                    proxyData.countryCode = str2;
                    notifyItemChanged(i);
                }
            });

        } else {
            viewHolder.tvCountry.setText(proxyData.country);
            ((RequestBuilder) ((RequestBuilder) Glide.with(viewHolder.imgFlag.getContext()).load("https://flagcdn.com/w80/" + proxyData.countryCode + ".png").placeholder(R.drawable.logo)).circleCrop()).into(viewHolder.imgFlag);
        }
        viewHolder.imgSelect.setImageResource(i == this.selected ? R.drawable.ic_select : R.drawable.ic_unselect);
        if (!proxyData.noProxy) {
            boolean z = proxyData.isWorking;
        }
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i2 = selected;
                if (i != i2) {
                    selected = i;
                    notifyItemChanged(i2);
                    notifyItemChanged(selected);
                    cb.onClick(proxyData, i);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.data.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgFlag;
        ImageView imgSelect;
        TextView tvCountry;
        TextView tvLine;

        ViewHolder(View view) {
            super(view);
            this.tvLine = (TextView) view.findViewById(R.id.tvLine);
            this.tvCountry = (TextView) view.findViewById(R.id.tvCountry);
            this.imgFlag = (ImageView) view.findViewById(R.id.imgFlag);
            this.imgSelect = (ImageView) view.findViewById(R.id.imgSelect);
        }
    }

    public void setSelected(int i) {
        int i2 = this.selected;
        this.selected = i;
        notifyItemChanged(i2);
        notifyItemChanged(this.selected);
    }
}
