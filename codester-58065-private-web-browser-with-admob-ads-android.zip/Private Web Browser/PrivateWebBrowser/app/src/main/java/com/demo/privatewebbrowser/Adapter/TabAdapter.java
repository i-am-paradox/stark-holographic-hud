package com.demo.privatewebbrowser.Adapter;

import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.demo.privatewebbrowser.R;
import com.demo.privatewebbrowser.UtilsSaveData.TabManager;

public class TabAdapter extends RecyclerView.Adapter<TabAdapter.VH> {
    private final OnTabChange changeCB;
    private final OnCardClick clickCB;

    public interface OnCardClick {
        void select(int i);
    }

    public interface OnTabChange {
        void changed();
    }

    public TabAdapter(OnCardClick onCardClick, OnTabChange onTabChange) {
        this.clickCB = onCardClick;
        this.changeCB = onTabChange;
    }

    public static class VH extends RecyclerView.ViewHolder {
        ImageView img;
        ImageView imgClose;
        RelativeLayout rlTabbg;
        TextView txt;
        TextView txtTabName;

        VH(View view) {
            super(view);
            this.img = (ImageView) view.findViewById(R.id.imgThumnail);
            this.imgClose = (ImageView) view.findViewById(R.id.imgClose);
            this.txt = (TextView) view.findViewById(R.id.txtUrl);
            this.txtTabName = (TextView) view.findViewById(R.id.txtTabName);
            this.rlTabbg = (RelativeLayout) view.findViewById(R.id.rlTabbg);
        }
    }

    @Override
    public VH onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new VH(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_tab, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(VH vh, int i) {
        TabManager.Tab tab = TabManager.get(i);
        if (tab.thumb != null) {
            vh.rlTabbg.setBackgroundResource(R.drawable.orange_yes_text_bg);
            vh.img.setImageBitmap(BitmapFactory.decodeFile(tab.thumb));
        } else {
            vh.rlTabbg.setBackgroundResource(R.drawable.orange_yes_text_bg);
            vh.img.setImageResource(R.drawable.ic_tab1);
        }
        vh.txt.setText(tab.url.equals("about:blank") ? "New tab" : tab.url);
        vh.txtTabName.setText(tab.title);
        vh.txtTabName.setSelected(true);
        vh.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickCB.select(i);
            }
        });
        vh.imgClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TabManager.close(i);
                notifyItemRemoved(i);
                notifyItemRangeChanged(i, getItemCount());
                OnTabChange onTabChange = changeCB;
                if (onTabChange != null) {
                    onTabChange.changed();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return TabManager.size();
    }

    public void refresh() {
        notifyDataSetChanged();
    }
}
