package com.demo.privatewebbrowser.Activity;

import android.content.SharedPreferences;
import android.widget.CompoundButton;


public final class SettingActivityCompoundButton implements CompoundButton.OnCheckedChangeListener {
    public final SettingActivity act1;
    public final SharedPreferences sp1;

    public SettingActivityCompoundButton(SettingActivity settingActivity, SharedPreferences sharedPreferences) {
        this.act1 = settingActivity;
        this.sp1 = sharedPreferences;
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        this.act1.SettingActivityCompoundButtonCall(this.sp1, compoundButton, z);
    }
}
