package com.demo.privatewebbrowser.Activity;

import androidx.activity.result.ActivityResultCallback;
import java.util.Map;


public final class HomeBrowserActivityActivityResultCallback implements ActivityResultCallback {
    public final HomeBrowserActivity act1;

    public HomeBrowserActivityActivityResultCallback(HomeBrowserActivity homeBrowserActivity) {
        this.act1 = homeBrowserActivity;
    }

    @Override
    public void onActivityResult(Object obj) {
        this.act1.HomeBrowserActivityActivityResultCallbackCall((Map) obj);
    }
}
