package com.demo.privatewebbrowser.UtilsSaveData;

public final class SearchPref {
    public static final String KEY_AUTO_SUGGEST = "auto_suggest";
    public static final String KEY_ENGINE = "engine";
    public static final String PREF_NAME = "search_prefs";

    private SearchPref() {
    }

    public enum Engine {
        GOOGLE("google", "https://www.google.com/search?q="),
        DUCKDUCKGO("duck", "https://duckduckgo.com/?q="),
        BING("bing", "https://www.bing.com/search?q="),
        YAHOO("yahoo", "https://search.yahoo.com/search?p=");
        
        public final String id;
        public final String prefix;

        private Engine(String str, String str2) {
            this.id = str;
            this.prefix = str2;
        }

        public static Engine fromId(String str) {
            for (Engine engine : values()) {
                if (engine.id.equals(str)) {
                    return engine;
                }
            }
            return GOOGLE;
        }
    }
}
