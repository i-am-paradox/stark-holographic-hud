package com.demo.privatewebbrowser.UtilsSaveData;


public final class CountryResolverRunnable implements Runnable {
    public final CountryResolver.OnCountryResolved onCou1;
    public final String st1;
    public final String st2;

    public CountryResolverRunnable(CountryResolver.OnCountryResolved onCountryResolved, String str, String str2) {
        this.onCou1 = onCountryResolved;
        this.st1 = str;
        this.st2 = str2;
    }

    @Override
    public void run() {
        this.onCou1.onResult(this.st1, this.st2);
    }
}
