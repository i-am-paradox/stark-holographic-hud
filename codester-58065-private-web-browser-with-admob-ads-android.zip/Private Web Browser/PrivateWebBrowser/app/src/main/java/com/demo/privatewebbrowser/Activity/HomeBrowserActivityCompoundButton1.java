package com.demo.privatewebbrowser.Activity;

import android.content.SharedPreferences;
import android.widget.CompoundButton;


public final class HomeBrowserActivityCompoundButton1 implements CompoundButton.OnCheckedChangeListener {
    public final HomeBrowserActivity act1;
    public final SharedPreferences sp1;

    public HomeBrowserActivityCompoundButton1(HomeBrowserActivity homeBrowserActivity, SharedPreferences sharedPreferences) {
        this.act1 = homeBrowserActivity;
        this.sp1 = sharedPreferences;
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        this.act1.HomeBrowserActivityCompoundButton1Call(this.sp1, compoundButton, z);
    }
}
