package com.demo.privatewebbrowser.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import com.demo.privatewebbrowser.R;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import okhttp3.OkHttpClient;
import okhttp3.Request;

public class AutoSuggestAdapter extends ArrayAdapter<String> implements Filterable {
    
    public final OkHttpClient http = new OkHttpClient();
    private final LayoutInflater inflater;
    
    public final List<String> items = new ArrayList();

    public AutoSuggestAdapter(Context context) {
        super(context, 0);
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.inflater.inflate(R.layout.row_suggest, viewGroup, false);
        }
        ((TextView) view.findViewById(R.id.txtSuggest)).setText(this.items.get(i));
        return view;
    }

    @Override
    public int getCount() {
        return this.items.size();
    }

    @Override
    public String getItem(int i) {
        return this.items.get(i);
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            public FilterResults performFiltering(CharSequence charSequence) {
                FilterResults filterResults = new FilterResults();
                if (charSequence == null || charSequence.length() < 2) {
                    filterResults.values = Collections.emptyList();
                    filterResults.count = 0;
                    return filterResults;
                }
                try {
                    JsonArray asJsonArray = JsonParser.parseString(AutoSuggestAdapter.this.http.newCall(new Request.Builder().url("https://suggestqueries.google.com/complete/search?client=firefox&q=" + URLEncoder.encode(charSequence.toString(), "UTF-8")).build()).execute().body().string()).getAsJsonArray().get(1).getAsJsonArray();
                    ArrayList arrayList = new ArrayList();
                    Iterator<JsonElement> it = asJsonArray.iterator();
                    while (it.hasNext()) {
                        arrayList.add(it.next().getAsString());
                    }
                    filterResults.values = arrayList;
                    filterResults.count = arrayList.size();
                    return filterResults;
                } catch (Exception unused) {
                    filterResults.values = Collections.emptyList();
                    filterResults.count = 0;
                    return filterResults;
                }
            }

            @Override
            public void publishResults(CharSequence charSequence, FilterResults filterResults) {
                AutoSuggestAdapter.this.items.clear();
                if (filterResults.values instanceof List) {
                    AutoSuggestAdapter.this.items.addAll((Collection) filterResults.values);
                }
                AutoSuggestAdapter.this.notifyDataSetChanged();
            }
        };
    }
}
