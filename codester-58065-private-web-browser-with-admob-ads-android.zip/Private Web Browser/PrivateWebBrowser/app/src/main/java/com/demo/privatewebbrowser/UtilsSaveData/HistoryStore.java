package com.demo.privatewebbrowser.UtilsSaveData;

import android.content.Context;
import android.content.SharedPreferences;
import com.demo.privatewebbrowser.Model.HistoryItem;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class HistoryStore {
    private static final String KEY = "history_json";
    private static final Type LST = new TypeToken<List<HistoryItem>>() {
    }.getType();
    private static final int MAX = 100;
    private static final String PREF = "history_prefs";
    private static final Gson gson = new Gson();

    private static SharedPreferences sp(Context context) {
        return context.getSharedPreferences(PREF, 0);
    }

    public static void add(Context context, HistoryItem historyItem) {
        List<HistoryItem> all = getAll(context);
        Iterator<HistoryItem> it = all.iterator();
        while (true) {
            if (it.hasNext()) {
                if (it.next().url.equals(historyItem.url)) {
                    it.remove();
                    break;
                }
            } else {
                break;
            }
        }
        all.add(0, historyItem);
        if (all.size() > 100) {
            all.remove(all.size() - 1);
        }
        save(context, all);
    }

    public static List<HistoryItem> getAll(Context context) {
        List<HistoryItem> list = (List) gson.fromJson(context.getSharedPreferences(PREF, 0).getString(KEY, "[]"), LST);
        if (list != null) {
            return list;
        }
        return new ArrayList();
    }

    private static void save(Context context, List<HistoryItem> list) {
        SharedPreferences.Editor edit = context.getSharedPreferences(PREF, 0).edit();
        edit.putString(KEY, gson.toJson((Object) list));
        edit.commit();
    }

    public static void remove(Context context, String str) {
        List<HistoryItem> all = getAll(context);
        Iterator<HistoryItem> it = all.iterator();
        while (true) {
            if (it.hasNext()) {
                if (it.next().url.equals(str)) {
                    it.remove();
                    break;
                }
            } else {
                break;
            }
        }
        save(context, all);
    }

    public static void clear(Context context) {
        context.getSharedPreferences(PREF, 0).edit().clear().commit();
    }

    public static boolean isEmpty(Context context) {
        return getAll(context).isEmpty();
    }

    public static void clearHistory(Context context) {
        context.getSharedPreferences(PREF, 0).edit().clear().commit();
        HistoryNotification.cancel(context);
    }
}
