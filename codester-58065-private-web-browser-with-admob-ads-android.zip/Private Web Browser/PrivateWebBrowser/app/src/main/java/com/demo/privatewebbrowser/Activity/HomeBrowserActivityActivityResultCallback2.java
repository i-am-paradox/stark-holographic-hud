package com.demo.privatewebbrowser.Activity;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;


public final class HomeBrowserActivityActivityResultCallback2 implements ActivityResultCallback {
    public final HomeBrowserActivity act1;

    public HomeBrowserActivityActivityResultCallback2(HomeBrowserActivity homeBrowserActivity) {
        this.act1 = homeBrowserActivity;
    }

    @Override
    public void onActivityResult(Object obj) {
        this.act1.HomeBrowserActivityActivityResultCallback2Call((ActivityResult) obj);
    }
}
