package com.demo.privatewebbrowser.Activity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentActivity;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.demo.privatewebbrowser.Adapter.AutoSuggestAdapter;
import com.demo.privatewebbrowser.Model.HistoryItem;
import com.demo.privatewebbrowser.Model.ProxyData;
import com.demo.privatewebbrowser.R;
import com.demo.privatewebbrowser.UtilsSaveData.HistoryNotification;
import com.demo.privatewebbrowser.UtilsSaveData.HistoryStore;
import com.demo.privatewebbrowser.UtilsSaveData.SearchPref;
import com.demo.privatewebbrowser.UtilsSaveData.TabManager;
import com.demo.privatewebbrowser.WebWIndowData.SameWindowChrome;
import com.demo.privatewebbrowser.ads.AdsCommon;
import com.demo.privatewebbrowser.ads.MyApplication;
import com.facebook.ads.NativeAdLayout;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.navigation.NavigationView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class HomeBrowserActivity extends AppCompatActivity {
    private static final String KEY_DESKTOP = "desktop_mode";
    private static final String KEY_RAW = "selected_raw";
    private static final String KEY_SHOW_WEB = "show_web";
    private static final String PREFS = "proxy_prefs";
    private static final int REQ_TABS = 100;
    private static final String STATE_PREF = "home_state";
    public static OkHttpClient okProxy;
    public static ProxyData selected;
    public static TextView txtTabCount;
    public static TextView txtTabCount2;
    public static WebView web;
    private boolean autoSuggestEnabled;
    CheckBox cbDesktop;
    
    public boolean clearOnNextPageFinished = false;
    private SearchPref.Engine currentEngine;
    MaterialCardView cvSelectCountry;
    
    public boolean desktopMode;
    
    public DrawerLayout drawerLayout;
    EditText edtFinalQuery;
    
    public AutoCompleteTextView edtQuery;
    
    public boolean firstPageDone = false;
    ImageView imgDrawer;
    ImageView imgFlag;
    ImageView imgGoogle;
    ImageView imgRefresh;
    ImageView imgSearch;
    
    public String lastQuery = "";
    
    public String lastSavedUrl = "";
    RelativeLayout llBrowser;
    LinearLayout llDaily;
    LinearLayout llFB;
    LinearLayout llInsta;
    LinearLayout llPinterest;
    LinearLayout llTiktok;
    LinearLayout llTwitter;
    LinearLayout llVimeo;
    LinearLayout llWA;
    LinearLayout lltab;
    LinearLayout lltab2;
    private String mobileUA;
    private NavigationView navigationView;
    private Pending pendingDownload;
    private final ActivityResultLauncher<String[]> permissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new HomeBrowserActivityActivityResultCallback(this));
    private final ActivityResultLauncher<Intent> pickProxy = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new HomeBrowserActivityActivityResultCallback2(this));
    RelativeLayout rlDesktop;
    RelativeLayout rlDownload;
    RelativeLayout rlForward;
    RelativeLayout rlHistory;
    RelativeLayout rlIncognito;
    RelativeLayout rlPolicy;
    RelativeLayout rlRate;
    RelativeLayout rlSearchdata;
    RelativeLayout rlSetting;
    RelativeLayout rlShare;
    RelativeLayout rlWebShow;
    
    public boolean skipNextSave = false;
    private AutoSuggestAdapter suggestAdapter;
    private final Handler ui = new Handler(Looper.getMainLooper());
    
    public boolean userInitiatedLoad = false;

    
    public void HomeBrowserActivityActivityResultCallbackCall(Map map) {
        if (!areAllPermissionsGranted()) {
            Toast.makeText(this, "All requested permissions are required to continue.", Toast.LENGTH_LONG).show();
        }
    }

    public static void updateTabIndicator() {
        int current = TabManager.current() + 1;
        txtTabCount.setText(String.valueOf(current));
        txtTabCount2.setText(String.valueOf(current));
    }

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        setContentView(R.layout.activity_homebrowser);

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) findViewById(R.id.Admob_Banner_Frame);
        LinearLayout adContainer = (LinearLayout) findViewById(R.id.banner_container);
        FrameLayout qureka = (FrameLayout) findViewById(R.id.qureka);
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);

        //Reguler Native Ads
        FrameLayout admob_native_frame = (FrameLayout) findViewById(R.id.Admob_Native_Frame);
        NativeAdLayout nativeAdLayout = (NativeAdLayout) findViewById(R.id.native_ad_container);
        FrameLayout maxNative = (FrameLayout) findViewById(R.id.max_native_ad_layout);
        AdsCommon.RegulerBigNative(this, admob_native_frame, nativeAdLayout, maxNative);



        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(1024);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.black));
        WindowCompat.setDecorFitsSystemWindows(window, true);

        if (getIntent().getBooleanExtra(HistoryNotification.EXTRA_FROM_NOTIFICATION, false)) {
            showHistoryDialog();
        }
        web = (WebView) findViewById(R.id.web);
        this.imgGoogle = (ImageView) findViewById(R.id.imgGoogle);
        this.edtQuery = (AutoCompleteTextView) findViewById(R.id.edtQuery);
        this.imgSearch = (ImageView) findViewById(R.id.imgSearch);
        this.imgDrawer = (ImageView) findViewById(R.id.imgDrawer);
        this.cvSelectCountry = (MaterialCardView) findViewById(R.id.cvSelectCountry);
        this.cvSelectCountry.setVisibility(View.GONE);
        this.imgFlag = (ImageView) findViewById(R.id.imgFlag);
        this.rlWebShow = (RelativeLayout) findViewById(R.id.rlWebShow);
        this.rlSearchdata = (RelativeLayout) findViewById(R.id.rlSearchdata);
        this.edtFinalQuery = (EditText) findViewById(R.id.edtFinalQuery);
        this.imgRefresh = (ImageView) findViewById(R.id.imgRefresh);
        this.llInsta = (LinearLayout) findViewById(R.id.llInsta);
        this.llFB = (LinearLayout) findViewById(R.id.llFB);
        this.llTiktok = (LinearLayout) findViewById(R.id.llTiktok);
        this.llPinterest = (LinearLayout) findViewById(R.id.llPinterest);
        this.llWA = (LinearLayout) findViewById(R.id.llWA);
        this.llVimeo = (LinearLayout) findViewById(R.id.llVimeo);
        this.llDaily = (LinearLayout) findViewById(R.id.llDaily);
        this.llTwitter = (LinearLayout) findViewById(R.id.llTwitter);
        this.llBrowser = (RelativeLayout) findViewById(R.id.llBrowser);
        txtTabCount = (TextView) findViewById(R.id.txtTabCount);
        this.lltab = (LinearLayout) findViewById(R.id.lltab);
        txtTabCount2 = (TextView) findViewById(R.id.txtTabCount2);
        this.lltab2 = (LinearLayout) findViewById(R.id.lltab2);
        if (!areAllPermissionsGranted()) {
            requestMissingPermissions();
        }
        TabManager.init(this);
        updateTabIndicator();
        boolean z = getSharedPreferences(STATE_PREF, 0).getBoolean(KEY_SHOW_WEB, false);
        String str = TabManager.currentTab().url;
        boolean equals = "about:blank".equals(str);
        String str2 = TabManager.currentTab().url;
        if (!"about:blank".equals(str2)) {
            web.loadUrl(str2);
        }
        SharedPreferences sharedPreferences2 = getSharedPreferences(SearchPref.PREF_NAME, 0);
        this.currentEngine = SearchPref.Engine.fromId(sharedPreferences2.getString(SearchPref.KEY_ENGINE, SearchPref.Engine.GOOGLE.id));
        this.autoSuggestEnabled = sharedPreferences2.getBoolean(SearchPref.KEY_AUTO_SUGGEST, true);
        updateSearchEngineIcon(this.currentEngine);
        this.cvSelectCountry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickProxy.launch(new Intent(HomeBrowserActivity.this, SelectCountryActivity.class));
            }
        });
        this.lltab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(HomeBrowserActivity.this, TabOpenActivity.class), 100);
            }
        });
        this.lltab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(HomeBrowserActivity.this, TabOpenActivity.class), 100);
            }
        });
        applyProxy(ProxyData.fromPref(getSharedPreferences(PREFS, 0).getString(KEY_RAW, ProxyData.NO_PROXY_SENTINEL)));
        if (!z || equals) {
            this.rlSearchdata.setVisibility(View.VISIBLE);
            this.llBrowser.setVisibility(View.VISIBLE);
            this.rlWebShow.setVisibility(View.GONE);
        } else {
            this.rlSearchdata.setVisibility(View.GONE);
            this.llBrowser.setVisibility(View.GONE);
            this.rlWebShow.setVisibility(View.VISIBLE);
            this.edtFinalQuery.setText(str);
            web.loadUrl(str);
        }
        handleHistoryIntent(getIntent());
        this.imgSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rlSearchdata.setVisibility(View.GONE);
                llBrowser.setVisibility(View.GONE);
                rlWebShow.setVisibility(View.VISIBLE);
                startSearch(edtQuery.getText().toString(), edtQuery);
            }
        });
        this.edtQuery.setInputType(16);
        this.edtQuery.setSingleLine(true);
        this.edtQuery.setImeOptions(3);
        this.edtQuery.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int i, KeyEvent keyEvent) {
                boolean z = keyEvent != null && keyEvent.getKeyCode() == 66 && keyEvent.getAction() == 0;
                if (i != 3 && i != 2 && i != 6 && !z) {
                    return false;
                }
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        rlSearchdata.setVisibility(View.GONE);
                        llBrowser.setVisibility(View.GONE);
                        rlWebShow.setVisibility(View.VISIBLE);
                        startSearch(edtQuery.getText().toString(), edtQuery);
                    }
                }, 10);
                return true;
            }
        });
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setUserAgentString(WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Version/4.0 ", ""));
        web.setLayerType(View.LAYER_TYPE_HARDWARE, (Paint) null);
        web.setWebViewClient(new InAppClient());
        web.setWebChromeClient(new SameWindowChrome(this, web));
        web.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String str, String str2, String str3, String str4, long j) {
                handleDownload(str, str2, str3, str4, j);
            }
        });
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        this.drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        this.navigationView = (NavigationView) findViewById(R.id.navigation_view);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawer);
        this.imgDrawer = imageView;
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer((int) GravityCompat.START);
            }
        });
        View headerView = this.navigationView.getHeaderView(0);
        this.rlSetting = (RelativeLayout) headerView.findViewById(R.id.rlSetting);
        this.rlHistory = (RelativeLayout) headerView.findViewById(R.id.rlHistory);
        this.rlDownload = (RelativeLayout) headerView.findViewById(R.id.rlDownload);
        this.rlIncognito = (RelativeLayout) headerView.findViewById(R.id.rlIncognito);
        this.rlDesktop = (RelativeLayout) headerView.findViewById(R.id.rlDesktop);
        this.rlForward = (RelativeLayout) headerView.findViewById(R.id.rlForward);
        this.rlShare = (RelativeLayout) headerView.findViewById(R.id.rlShare);
        this.rlRate = (RelativeLayout) headerView.findViewById(R.id.rlRate);
        this.rlPolicy = (RelativeLayout) headerView.findViewById(R.id.rlPolicy);
        this.cbDesktop = (CheckBox) headerView.findViewById(R.id.cbDesktop);
        SharedPreferences sharedPreferences3 = getSharedPreferences(PREFS, 0);
        this.mobileUA = WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Version/4.0 ", "");
        boolean z2 = sharedPreferences3.getBoolean(KEY_DESKTOP, false);
        this.cbDesktop.setChecked(z2);
        applyDesktopMode(z2);
        this.cbDesktop.setOnCheckedChangeListener(new HomeBrowserActivityCompoundButton1(this, sharedPreferences3));
        this.rlHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeBrowserActivity.this, HistoryActivity.class));
                drawerLayout.closeDrawer((int) GravityCompat.START);
            }
        });
        this.rlDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(HomeBrowserActivity.this, DownloadActivity.class));
                //drawerLayout.closeDrawer((int) GravityCompat.START);
            }
        });
        this.rlIncognito.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeBrowserActivity.this, IncognitoActivity.class));
                drawerLayout.closeDrawer((int) GravityCompat.START);
            }
        });
        this.rlSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeBrowserActivity.this, SettingActivity.class));
                drawerLayout.closeDrawer((int) GravityCompat.START);
            }
        });
        this.rlRate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + getPackageName())));
                } catch (ActivityNotFoundException unused) {
                    startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                }
                drawerLayout.closeDrawer((int) GravityCompat.START);
            }
        });
        this.rlShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View currentFocus = getCurrentFocus();
                if (currentFocus != null) {
                    currentFocus.clearFocus();
                }
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.TEXT", "Check out this amazing app:\n\nhttps://play.google.com/store/apps/details?id=" + getPackageName());
                startActivity(Intent.createChooser(intent, "Share App via"));
                drawerLayout.closeDrawer((int) GravityCompat.START);
            }
        });
        this.rlPolicy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View currentFocus = getCurrentFocus();
                if (currentFocus != null) {
                    currentFocus.clearFocus();
                }
                Intent intentPrivacy = new Intent(Intent.ACTION_VIEW, Uri.parse(MyApplication.PrivacyPolicy));
                intentPrivacy.setPackage("com.android.chrome");
                startActivity(intentPrivacy);
                drawerLayout.closeDrawer((int) GravityCompat.START);
            }
        });
        attachQuickSearch(this.llInsta, "Instagram");
        attachQuickSearch(this.llFB, "facebook");
        attachQuickSearch(this.llTiktok, "Tiktok");
        attachQuickSearch(this.llPinterest, "Pinterest");
        attachQuickSearch(this.llWA, "whatsapp");
        attachQuickSearch(this.llVimeo, "vimeo");
        attachQuickSearch(this.llDaily, "dailymotion");
        attachQuickSearch(this.llTwitter, "twitter");
        this.imgRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (web.getUrl() != null) {
                    web.reload();
                }
            }
        });
        if (this.autoSuggestEnabled) {
            AutoSuggestAdapter autoSuggestAdapter = new AutoSuggestAdapter(this);
            this.suggestAdapter = autoSuggestAdapter;
            this.edtQuery.setAdapter(autoSuggestAdapter);
            this.edtQuery.setThreshold(2);
            this.edtQuery.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                    edtQueryCall(adapterView, view, position, id);
                }
            });
        } else {
            this.edtQuery.setAdapter(null);
        }
        this.edtFinalQuery.setInputType(16);
        this.edtFinalQuery.setSingleLine(true);
        this.edtFinalQuery.setImeOptions(3);
        this.edtFinalQuery.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int i, KeyEvent keyEvent) {
                boolean z = keyEvent != null && keyEvent.getKeyCode() == 66 && keyEvent.getAction() == 0;
                if (i != 3 && i != 2 && i != 6 && !z) {
                    return false;
                }
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        HomeBrowserActivity homeBrowserActivity = HomeBrowserActivity.this;
                        homeBrowserActivity.startSearch(homeBrowserActivity.edtFinalQuery.getText().toString(), HomeBrowserActivity.this.edtFinalQuery);
                    }
                }, 100);
                return true;
            }
        });
    }

    
    public void HomeBrowserActivityCompoundButton1Call(SharedPreferences sharedPreferences, CompoundButton compoundButton, boolean z) {
        applyDesktopMode(z);
        sharedPreferences.edit().putBoolean(KEY_DESKTOP, z).apply();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                HomeBrowserActivity.this.drawerLayout.closeDrawer((int) GravityCompat.START);
            }
        }, 400);
    }

    
    public void edtQueryCall(AdapterView adapterView, View view, int i, long j) {
        String item = this.suggestAdapter.getItem(i);
        if (item != null) {
            this.edtQuery.setText(item);
            this.edtQuery.setSelection(item.length());
            this.rlSearchdata.setVisibility(View.GONE);
            this.llBrowser.setVisibility(View.GONE);
            this.rlWebShow.setVisibility(View.VISIBLE);
            startSearch(this.edtQuery.getText().toString(), this.edtQuery);
        }
    }

    private void attachQuickSearch(View view, String str) {
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtQuery.setText(str);
                rlSearchdata.setVisibility(View.GONE);
                llBrowser.setVisibility(View.GONE);
                rlWebShow.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        HomeBrowserActivity homeBrowserActivity = HomeBrowserActivity.this;
                        homeBrowserActivity.startSearch(homeBrowserActivity.edtQuery.getText().toString(), HomeBrowserActivity.this.edtQuery);
                    }
                }, 100);
            }
        });
    }
    
    public void startSearch(String str, EditText editText) {
        if (editText != null) {
            hideKeyboard(editText);
        }
        String trim = str.trim();
        if (trim.isEmpty()) {
            Toast.makeText(this, "Enter something to open", Toast.LENGTH_SHORT).show();
            this.rlSearchdata.setVisibility(View.VISIBLE);
            this.llBrowser.setVisibility(View.VISIBLE);
            this.rlWebShow.setVisibility(View.GONE);
            return;
        }
        String str2 = (trim.startsWith("http://") || trim.startsWith("https://")) ? trim : this.currentEngine.prefix + Uri.encode(trim);
        if (editText == this.edtQuery || this.rlWebShow.getVisibility() != View.VISIBLE) {
            this.clearOnNextPageFinished = true;
        }
        web.stopLoading();
        web.clearHistory();
        web.clearCache(true);
        TabManager.setTitle(trim.isEmpty() ? "New tab" : trim);
        this.edtFinalQuery.setText(str2);
        this.edtQuery.setText("");
        this.userInitiatedLoad = true;
        this.lastQuery = trim;
        ProxyData proxyData = selected;
        if (proxyData == null) {
            TabManager.setUrl(str2);
            web.loadUrl(str2);
        } else if (!proxyData.isWorking) {
            Toast.makeText(this, "Pick a working proxy first!", Toast.LENGTH_SHORT).show();
        } else {
            this.ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    web.loadUrl(str2);
                }
            }, 1000);
        }
    }

    private void openFromHistory(String str) {
        this.rlSearchdata.setVisibility(View.GONE);
        this.llBrowser.setVisibility(View.GONE);
        this.rlWebShow.setVisibility(View.VISIBLE);
        this.edtQuery.setText("");
        this.edtFinalQuery.setText(str);
        this.skipNextSave = true;
        this.userInitiatedLoad = true;
        ProxyData proxyData = selected;
        if (proxyData == null) {
            web.loadUrl(str);
        } else if (proxyData.isWorking) {
            Toast.makeText(this, "Loading via proxy in 1s…", Toast.LENGTH_SHORT).show();
            this.ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    web.loadUrl(str);
                }
            }, 1000);
        } else {
            Toast.makeText(this, "Pick a working proxy first!", Toast.LENGTH_SHORT).show();
        }
    }

    
    public void applyProxy(ProxyData proxyData) {
        OkHttpClient okHttpClient = null;
        selected = proxyData.noProxy ? null : proxyData;
        if (!proxyData.noProxy) {
            okHttpClient = SelectCountryActivity.buildProxyClient(proxyData);
        }
        okProxy = okHttpClient;
        if (proxyData.countryCode == null || proxyData.countryCode.isEmpty()) {
            this.imgFlag.setImageResource(R.drawable.ic_flagindia);
        } else {
            ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) Glide.with((FragmentActivity) this).load("https://flagcdn.com/w80/" + proxyData.countryCode.toLowerCase() + ".png").placeholder(R.drawable.ic_flagindia)).error(R.drawable.ic_flagindia)).circleCrop()).into(this.imgFlag);
        }
        getSharedPreferences(PREFS, 0).edit().putString(KEY_RAW, proxyData.toPref()).apply();
        if (web.getUrl() != null && !web.getUrl().isEmpty()) {
            web.reload();
        }
    }

    private void handleHistoryIntent(Intent intent) {
        String stringExtra;
        if (intent != null && (stringExtra = intent.getStringExtra("history_url")) != null && !stringExtra.isEmpty()) {
            openFromHistory(stringExtra);
        }
    }

    @Override
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleHistoryIntent(intent);
    }

    
    public static Map<String, String> toSingleMap(Headers headers) {
        HashMap hashMap = new HashMap();
        for (String next : headers.names()) {
            if (!"Set-Cookie".equalsIgnoreCase(next)) {
                hashMap.put(next, TextUtils.join(", ", headers.values(next)));
            }
        }
        return hashMap;
    }

    private class InAppClient extends WebViewClient {
        private final AtomicBoolean retried;


        private InAppClient() {
            this.retried = new AtomicBoolean(false);
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest webResourceRequest) {
            String str;
            if (HomeBrowserActivity.okProxy == null || HomeBrowserActivity.selected == null || !HomeBrowserActivity.selected.isWorking) {
                return super.shouldInterceptRequest(webView, webResourceRequest);
            }
            if (!"GET".equalsIgnoreCase(webResourceRequest.getMethod())) {
                return super.shouldInterceptRequest(webView, webResourceRequest);
            }
            String uri = webResourceRequest.getUrl().toString();
            Log.d("Selectproxy", "→ " + uri + "  via  " + HomeBrowserActivity.selected.host + ":" + HomeBrowserActivity.selected.port);
            try {
                Request.Builder url = new Request.Builder().url(webResourceRequest.getUrl().toString());
                for (Map.Entry next : webResourceRequest.getRequestHeaders().entrySet()) {
                    url.addHeader((String) next.getKey(), (String) next.getValue());
                }
                url.header("Accept-Encoding", "identity");
                Response execute = HomeBrowserActivity.okProxy.newCall(url.build()).execute();
                CookieManager instance = CookieManager.getInstance();
                for (String cookie : execute.headers("Set-Cookie")) {
                    instance.setCookie(webResourceRequest.getUrl().getHost(), cookie);
                }
                instance.flush();
                String header = execute.header("content-type", "");
                String trim = header.isEmpty() ? "application/octet-stream" : header.split(";", 2)[0].trim();
                if (!uri.contains("googlevideo.com") && !uri.contains("video") && !uri.endsWith(".mp4") && !uri.endsWith(".m3u8")) {
                    if (!uri.endsWith(".ts")) {
                        int code = execute.code();
                        if (code == 204) {
                            str = "No Content";
                        } else if (code == 206) {
                            str = "Partial Content";
                        } else if (code == 304) {
                            str = "Not Modified";
                        } else if (code == 500) {
                            str = "Internal Server Error";
                        } else if (code == 301) {
                            str = "Moved Permanently";
                        } else if (code == 302) {
                            str = "Found";
                        } else if (code == 400) {
                            str = "Bad Request";
                        } else if (code == 401) {
                            str = "Unauthorized";
                        } else if (code == 403) {
                            str = "Forbidden";
                        } else if (code != 404) {
                            str = "OK";
                            switch (code) {
                                case 201:
                                    str = "Created";
                                    break;
                                case 202:
                                    str = "Accepted";
                                    break;
                            }
                        } else {
                            str = "Not Found";
                        }
                        return new WebResourceResponse(trim, (String) null, code, str, HomeBrowserActivity.toSingleMap(execute.headers()), execute.body().byteStream());
                    }
                }
                return super.shouldInterceptRequest(webView, webResourceRequest);
            } catch (Exception unused) {
                return super.shouldInterceptRequest(webView, webResourceRequest);
            }
        }

        @Override
        public void onReceivedError(WebView webView, WebResourceRequest webResourceRequest, WebResourceError webResourceError) {
            super.onReceivedError(webView, webResourceRequest, webResourceError);
            String uri = webResourceRequest.getUrl().toString();
            int errorCode = webResourceError.getErrorCode();
            if ((uri.endsWith(".mp4") || uri.contains("video") || uri.endsWith(".m3u8") || uri.endsWith(".ts") || uri.contains("googlevideo.com")) && !this.retried.getAndSet(true)) {
                Log.d("Selectproxy", "First video segment blocked (" + errorCode + ") → reloading page");
                Objects.requireNonNull(webView);
                webView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        webView.reload();
                    }
                }, 1200);
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
            String scheme = webResourceRequest.getUrl().getScheme();
            webResourceRequest.getUrl();
            return !"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme);
        }

        @Override
        public void onReceivedError(WebView webView, int i, String str, String str2) {
            super.onReceivedError(webView, i, str, str2);
            if (i == -8 || i == -6) {
                webView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        int indexOf;
                        if (HomeBrowserActivity.selected != null && SelectCountryActivity.proxies.size() >= 2 && (indexOf = SelectCountryActivity.proxies.indexOf(HomeBrowserActivity.selected)) != -1) {
                            int i = 1;
                            while (i < SelectCountryActivity.proxies.size()) {
                                ProxyData proxyData = SelectCountryActivity.proxies.get((indexOf + i) % SelectCountryActivity.proxies.size());
                                if (proxyData.noProxy || !proxyData.isWorking) {
                                    i++;
                                } else {
                                    HomeBrowserActivity.this.applyProxy(proxyData);
                                    webView.loadUrl(str2);
                                    return;
                                }
                            }
                        }
                    }
                }, 2000);

            }
        }

        @Override
        public void onReceivedSslError(WebView webView, final SslErrorHandler sslErrorHandler, SslError sslError) {
            AlertDialog.Builder builder = new AlertDialog.Builder(HomeBrowserActivity.this);
            builder.setTitle((CharSequence) "SSL Certificate Error");
            builder.setMessage((CharSequence) "The website's security certificate is not trusted. Do you want to continue anyway?");
            builder.setPositiveButton((CharSequence) "Continue", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    sslErrorHandler.proceed();
                }
            });
            builder.setNegativeButton((CharSequence) "Cancel", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    sslErrorHandler.cancel();
                }
            });
            builder.create().show();
        }

        @Override
        public void onPageFinished(WebView webView, String str) {
            super.onPageFinished(webView, str);
            if (HomeBrowserActivity.this.desktopMode) {
                Objects.requireNonNull(webView);
                webView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        boolean unused = webView.zoomOut();
                    }
                }, 50);
            }
            if (HomeBrowserActivity.this.clearOnNextPageFinished) {
                webView.clearHistory();
                HomeBrowserActivity.this.clearOnNextPageFinished = false;
            }
            TabManager.setUrl(str);
            TabManager.captureAndSaveThumb(HomeBrowserActivity.web);
            HomeBrowserActivity.this.edtFinalQuery.setText(str);
            if (!HomeBrowserActivity.this.firstPageDone) {
                HomeBrowserActivity.this.firstPageDone = true;
            } else if (HomeBrowserActivity.this.skipNextSave) {
                HomeBrowserActivity.this.skipNextSave = false;
                HomeBrowserActivity.this.userInitiatedLoad = false;
            } else if (HomeBrowserActivity.this.userInitiatedLoad) {
                HomeBrowserActivity.this.userInitiatedLoad = false;
                if (!str.equals(HomeBrowserActivity.this.lastSavedUrl)) {
                    String title = webView.getTitle();
                    HomeBrowserActivity homeBrowserActivity = HomeBrowserActivity.this;
                    if (title == null || title.isEmpty()) {
                        title = HomeBrowserActivity.this.lastQuery;
                    }
                    HistoryStore.add(homeBrowserActivity, new HistoryItem(title, str));
                    HomeBrowserActivity.this.lastSavedUrl = str;
                    webView.evaluateJavascript("(function(){  var css='*{filter:none!important;-webkit-filter:none!important;}';  var s=document.createElement('style');  s.type='text/css';  s.appendChild(document.createTextNode(css));  document.head.appendChild(s);})();", (ValueCallback) null);
                    webView.evaluateJavascript("(function(){  var btn=document.querySelector('.vjs-big-play-button,                                 .bigPlayButton,                                 .btnPlay');  if(btn){ btn.click(); }})();", (ValueCallback) null);
                }
            }
        }
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 100 && i2 == -1) {
            TabManager.select((intent == null || !intent.hasExtra("tab")) ? TabManager.current() : intent.getIntExtra("tab", TabManager.current()));
            updateTabIndicator();
            String str = TabManager.currentTab().url;
            if (!"about:blank".equals(str)) {
                this.rlSearchdata.setVisibility(View.GONE);
                this.llBrowser.setVisibility(View.GONE);
                this.rlWebShow.setVisibility(View.VISIBLE);
                web.loadUrl(str);
                return;
            }
            this.rlSearchdata.setVisibility(View.VISIBLE);
            this.llBrowser.setVisibility(View.VISIBLE);
            this.rlWebShow.setVisibility(View.GONE);
        }
    }

    
    public void HomeBrowserActivityActivityResultCallback2Call(ActivityResult activityResult) {
        ProxyData proxyData;
        if (activityResult.getResultCode() == -1 && activityResult.getData() != null && (proxyData = (ProxyData) activityResult.getData().getParcelableExtra("proxy")) != null) {
            applyProxy(proxyData);
        }
    }

    @SuppressLint("GestureBackNavigation")
    public void onBackPressed() {
        if (this.drawerLayout.isDrawerOpen((int) GravityCompat.START)) {
            this.drawerLayout.closeDrawer((int) GravityCompat.START);
        } else if (this.rlWebShow.getVisibility() != View.VISIBLE) {
            if (!TabManager.currentTab().url.equals("about:blank")) {
                this.rlSearchdata.setVisibility(View.VISIBLE);
                this.rlWebShow.setVisibility(View.GONE);
                this.edtQuery.requestFocus();
            }
            showClearDialog();
        } else if (web.canGoBack()) {
            this.skipNextSave = true;
            web.goBack();
        } else {
            this.rlSearchdata.setVisibility(View.VISIBLE);
            this.llBrowser.setVisibility(View.VISIBLE);
            this.rlWebShow.setVisibility(View.GONE);
            web.stopLoading();
            web.clearHistory();
            this.edtQuery.requestFocus();
            TabManager.resetCurrentTab();
            TabManager.setUrl("about:blank");
            TabManager.setTitle("New tab");
            getSharedPreferences(STATE_PREF, 0).edit().putBoolean(KEY_SHOW_WEB, false).apply();
        }
    }

    private void showClearDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.exit_dialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().setLayout(-1, -1);
            dialog.getWindow().setGravity(17);
        }
        ((TextView) dialog.findViewById(R.id.txtNo)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        ((TextView) dialog.findViewById(R.id.txtYes)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void showHistoryDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.delete_history_layout);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().setLayout(-1, -1);
            dialog.getWindow().setGravity(17);
        }
        ((TextView) dialog.findViewById(R.id.txtNo)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        ((TextView) dialog.findViewById(R.id.txtYes)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                HistoryStore.clearHistory(HomeBrowserActivity.this);
                Toast.makeText(HomeBrowserActivity.this, "History cleared..", Toast.LENGTH_SHORT).show();
            }
        });
        dialog.show();
    }


    @Override
    public void onResume() {
        super.onResume();
        View currentFocus = getCurrentFocus();
        if (currentFocus != null) {
            currentFocus.clearFocus();
            ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
        }
        this.currentEngine = SearchPref.Engine.fromId(getSharedPreferences(SearchPref.PREF_NAME, 0).getString(SearchPref.KEY_ENGINE, SearchPref.Engine.GOOGLE.id));
        updateAutoSuggestState();
        updateSearchEngineIcon(this.currentEngine);
        updateTabIndicator();
    }


    static class ClassWEB6 {
        static final int[] SaveDataSearchPrefEngine;

        static {
            int[] iArr = new int[SearchPref.Engine.values().length];
            SaveDataSearchPrefEngine = iArr;
            iArr[SearchPref.Engine.GOOGLE.ordinal()] = 1;
            SaveDataSearchPrefEngine[SearchPref.Engine.DUCKDUCKGO.ordinal()] = 2;
            SaveDataSearchPrefEngine[SearchPref.Engine.BING.ordinal()] = 3;
            try {
                SaveDataSearchPrefEngine[SearchPref.Engine.YAHOO.ordinal()] = 4;
            } catch (NoSuchFieldError unused) {
            }
        }
    }

    private void updateSearchEngineIcon(SearchPref.Engine engine) {
        int i;
        int i2 = ClassWEB6.SaveDataSearchPrefEngine[engine.ordinal()];
        if (i2 == 1) {
            i = R.drawable.ic_google;
        } else if (i2 == 2) {
            i = R.drawable.ic_duckduckgo;
        } else if (i2 == 3) {
            i = R.drawable.ic_bing;
        } else if (i2 != 4) {
            i = R.drawable.ic_google;
        } else {
            i = R.drawable.ic_yahoo;
        }
        this.imgGoogle.setImageResource(i);
    }

    @Override
    public void onPause() {
        super.onPause();
        getSharedPreferences(STATE_PREF, 0).edit().putBoolean(KEY_SHOW_WEB, this.rlWebShow.getVisibility() == View.VISIBLE && web.getUrl() != null && !"about:blank".equals(web.getUrl())).apply();
    }

    private void updateAutoSuggestState() {
        boolean z = getSharedPreferences(SearchPref.PREF_NAME, 0).getBoolean(SearchPref.KEY_AUTO_SUGGEST, true);
        if (z != this.autoSuggestEnabled) {
            this.autoSuggestEnabled = z;
            if (z) {
                if (this.suggestAdapter == null) {
                    this.suggestAdapter = new AutoSuggestAdapter(this);
                }
                this.edtQuery.setAdapter(this.suggestAdapter);
                this.edtQuery.setThreshold(2);
                this.edtQuery.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                        edtQueryCall2(adapterView, view, position, id);
                    }
                });
                return;
            }
            this.edtQuery.setAdapter(null);
        }
    }

    
    public void edtQueryCall2(AdapterView adapterView, View view, int i, long j) {
        String item = this.suggestAdapter.getItem(i);
        if (item != null) {
            this.edtQuery.setText(item);
            this.edtQuery.setSelection(item.length());
            this.rlSearchdata.setVisibility(View.GONE);
            this.llBrowser.setVisibility(View.GONE);
            this.rlWebShow.setVisibility(View.VISIBLE);
            startSearch(this.edtQuery.getText().toString(), this.edtQuery);
        }
    }

    
    public void handleDownload(String str, String str2, String str3, String str4, long j) {
        if (ActivityCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 42);
            this.pendingDownload = new Pending(str, str2, str3, str4);
            return;
        }
        getSharedPreferences("downloads", 0).edit().putLong(String.valueOf(((DownloadManager) getSystemService("download")).enqueue(new DownloadManager.Request(Uri.parse(str)).addRequestHeader("User-Agent", str2).addRequestHeader("Cookie", CookieManager.getInstance().getCookie(str)).setMimeType(str4).setNotificationVisibility(1).setAllowedOverMetered(true).setAllowedOverRoaming(true).setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(str, str3, str4)))), System.currentTimeMillis()).apply();
    }

    private static class Pending {
        String contentDisposition;
        String mimeType;
        String url;
        String userAgent;

        Pending(String str, String str2, String str3, String str4) {
            this.url = str;
            this.userAgent = str2;
            this.contentDisposition = str3;
            this.mimeType = str4;
        }
    }

    private void hideKeyboard(View view) {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService("input_method");
        if (inputMethodManager != null) {
            inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    private void applyDesktopMode(boolean z) {
        WebSettings settings = web.getSettings();
        settings.setSupportZoom(z);
        settings.setBuiltInZoomControls(z);
        settings.setDisplayZoomControls(false);
        if (z) {
            settings.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(true);
            DisplayMetrics displayMetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            web.setInitialScale((int) ((((float) displayMetrics.widthPixels) * 100.0f) / 1200.0f));
        } else {
            settings.setUserAgentString(WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Version/4.0 ", ""));
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(false);
            settings.setSupportZoom(false);
            settings.setBuiltInZoomControls(false);
            settings.setDisplayZoomControls(false);
        }
        if (web.getUrl() != null && !web.getUrl().isEmpty()) {
            web.reload();
        }
    }

    private String[] permissionsForThisSdk() {
        ArrayList arrayList = new ArrayList();
        if (Build.VERSION.SDK_INT >= 33) {
            arrayList.add("android.permission.POST_NOTIFICATIONS");
        }
        if (Build.VERSION.SDK_INT >= 33) {
            arrayList.add("android.permission.READ_MEDIA_IMAGES");
            arrayList.add("android.permission.READ_MEDIA_VIDEO");
            arrayList.add("android.permission.READ_MEDIA_AUDIO");
        } else {
            arrayList.add("android.permission.READ_EXTERNAL_STORAGE");
        }
        if (Build.VERSION.SDK_INT <= 28) {
            arrayList.add("android.permission.WRITE_EXTERNAL_STORAGE");
        }
        return (String[]) arrayList.toArray(new String[0]);
    }

    private boolean areAllPermissionsGranted() {
        for (String checkSelfPermission : permissionsForThisSdk()) {
            if (ContextCompat.checkSelfPermission(this, checkSelfPermission) != 0) {
                return false;
            }
        }
        return true;
    }

    private void requestMissingPermissions() {
        ArrayList arrayList = new ArrayList();
        for (String str : permissionsForThisSdk()) {
            if (ContextCompat.checkSelfPermission(this, str) != 0) {
                arrayList.add(str);
            }
        }
        if (!arrayList.isEmpty()) {
            this.permissionLauncher.launch((String[]) arrayList.toArray(new String[0]));
        }
    }
}
