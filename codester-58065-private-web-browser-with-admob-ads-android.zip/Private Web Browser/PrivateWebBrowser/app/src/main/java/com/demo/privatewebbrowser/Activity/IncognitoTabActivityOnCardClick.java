package com.demo.privatewebbrowser.Activity;

import com.demo.privatewebbrowser.Adapter.IncognitoTabAdapter;


public final class IncognitoTabActivityOnCardClick implements IncognitoTabAdapter.OnCardClick {
    public final IncognitoTabActivity act1;

    public IncognitoTabActivityOnCardClick(IncognitoTabActivity incognitoTabActivity) {
        this.act1 = incognitoTabActivity;
    }

    @Override
    public void select(int i) {
        this.act1.returnChoice(i);
    }
}
