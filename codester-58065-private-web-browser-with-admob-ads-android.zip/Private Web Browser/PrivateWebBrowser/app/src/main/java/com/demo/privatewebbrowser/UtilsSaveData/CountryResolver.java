package com.demo.privatewebbrowser.UtilsSaveData;

import android.os.Handler;
import android.os.Looper;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONException;
import org.json.JSONObject;

public class CountryResolver {

    public interface OnCountryResolved {
        void onResult(String str, String str2);
    }

    public static void fetchCountryFromIP(String str, final OnCountryResolved onCountryResolved) {
        new OkHttpClient().newCall(new Request.Builder().url("http://ip-api.com/json/" + str).build()).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException iOException) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        onCountryResolved.onResult("Unknown", "zz");
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String string = response.body().string();
                boolean isSuccessful = response.isSuccessful();
                String str = "Unknown";
                String str2 = "zz";
                if (isSuccessful) {
                    try {
                        JSONObject jSONObject = new JSONObject(string);
                        str = jSONObject.optString("country", str);
                        str2 = jSONObject.optString("countryCode", str2).toLowerCase();
                    } catch (JSONException unused) {
                    }
                }
                new Handler(Looper.getMainLooper()).post(new CountryResolverRunnable(onCountryResolved, str, str2));
            }
        });
    }
}
