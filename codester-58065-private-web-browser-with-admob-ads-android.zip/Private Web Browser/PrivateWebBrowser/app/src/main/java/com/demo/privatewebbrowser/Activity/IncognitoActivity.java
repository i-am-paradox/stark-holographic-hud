package com.demo.privatewebbrowser.Activity;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.demo.privatewebbrowser.Adapter.AutoSuggestAdapter;
import com.demo.privatewebbrowser.Model.ProxyData;
import com.demo.privatewebbrowser.R;
import com.demo.privatewebbrowser.UtilsSaveData.IncognitoTabManager;
import com.demo.privatewebbrowser.UtilsSaveData.SearchPref;
import com.demo.privatewebbrowser.UtilsSaveData.TabManager;
import com.demo.privatewebbrowser.WebWIndowData.SameWindowChrome;
import com.demo.privatewebbrowser.ads.AdsCommon;
import com.demo.privatewebbrowser.ads.MyApplication;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.navigation.NavigationView;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class IncognitoActivity extends AppCompatActivity {
    private static final String KEY_DESKTOP = "desktop_mode";
    private static final String KEY_RAW = "selected_raw";
    private static final String KEY_SHOW_WEB = "show_web";
    private static final String PREFS = "proxy_prefs";
    private static final int REQ_TABS = 100;
    private static final String STATE_PREF = "home_state";
    public static OkHttpClient okProxy;
    public static ProxyData selected;
    public static WebView web;
    private boolean autoSuggestEnabled;
    CheckBox cbDesktop;
    
    public boolean clearOnNextPageFinished = false;
    private SearchPref.Engine currentEngine;
    MaterialCardView cvSelectCountry;
    
    public boolean desktopMode;
    
    public DrawerLayout drawerLayout;
    EditText edtFinalQuery;
    
    public AutoCompleteTextView edtQuery;
    ImageView imgDrawer;
    ImageView imgFlag;
    ImageView imgGoogle;
    ImageView imgRefresh;
    ImageView imgSearch;
    private String lastQuery = "";
    RelativeLayout llBrowser;
    LinearLayout llDaily;
    LinearLayout llFB;
    LinearLayout llInsta;
    LinearLayout llPinterest;
    LinearLayout llTiktok;
    LinearLayout llTwitter;
    LinearLayout llVimeo;
    LinearLayout llWA;
    LinearLayout lltab;
    LinearLayout lltab2;
    private String mobileUA;
    private NavigationView navigationView;
    private Pending pendingDownload;
    private final ActivityResultLauncher<Intent> pickProxy = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new IncognitoActivityActivityResultCallback(this));
    RelativeLayout rlDesktop;
    RelativeLayout rlDownload;
    RelativeLayout rlForward;
    RelativeLayout rlHistory;
    RelativeLayout rlIncognito;
    RelativeLayout rlPolicy;
    RelativeLayout rlRate;
    RelativeLayout rlSearchdata;
    RelativeLayout rlSetting;
    RelativeLayout rlShare;
    RelativeLayout rlWebShow;
    
    public boolean skipNextSave = false;
    private AutoSuggestAdapter suggestAdapter;
    TextView txtTabCount;
    TextView txtTabCount2;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private void updateTabIndicator() {
        int current = IncognitoTabManager.current() + 1;
        this.txtTabCount.setText(String.valueOf(current));
        this.txtTabCount2.setText(String.valueOf(current));
    }

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        setContentView(R.layout.activity_incognito);

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) findViewById(R.id.Admob_Banner_Frame);
        LinearLayout adContainer = (LinearLayout) findViewById(R.id.banner_container);
        FrameLayout qureka = (FrameLayout) findViewById(R.id.qureka);
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(1024);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.black));
        WindowCompat.setDecorFitsSystemWindows(window, true);

        web = (WebView) findViewById(R.id.web);
        this.imgGoogle = (ImageView) findViewById(R.id.imgGoogle);
        this.edtQuery = (AutoCompleteTextView) findViewById(R.id.edtQuery);
        this.imgSearch = (ImageView) findViewById(R.id.imgSearch);
        this.imgDrawer = (ImageView) findViewById(R.id.imgDrawer);
        this.cvSelectCountry = (MaterialCardView) findViewById(R.id.cvSelectCountry);
        this.cvSelectCountry.setVisibility(View.GONE);
        this.imgFlag = (ImageView) findViewById(R.id.imgFlag);
        this.rlWebShow = (RelativeLayout) findViewById(R.id.rlWebShow);
        this.rlSearchdata = (RelativeLayout) findViewById(R.id.rlSearchdata);
        this.edtFinalQuery = (EditText) findViewById(R.id.edtFinalQuery);
        this.imgRefresh = (ImageView) findViewById(R.id.imgRefresh);
        this.llInsta = (LinearLayout) findViewById(R.id.llInsta);
        this.llFB = (LinearLayout) findViewById(R.id.llFB);
        this.llTiktok = (LinearLayout) findViewById(R.id.llTiktok);
        this.llPinterest = (LinearLayout) findViewById(R.id.llPinterest);
        this.llWA = (LinearLayout) findViewById(R.id.llWA);
        this.llVimeo = (LinearLayout) findViewById(R.id.llVimeo);
        this.llDaily = (LinearLayout) findViewById(R.id.llDaily);
        this.llTwitter = (LinearLayout) findViewById(R.id.llTwitter);
        this.llBrowser = (RelativeLayout) findViewById(R.id.llBrowser);
        this.txtTabCount = (TextView) findViewById(R.id.txtTabCount);
        this.lltab = (LinearLayout) findViewById(R.id.lltab);
        this.txtTabCount2 = (TextView) findViewById(R.id.txtTabCount2);
        this.lltab2 = (LinearLayout) findViewById(R.id.lltab2);
        IncognitoTabManager.init(this);
        updateTabIndicator();
        boolean z = getSharedPreferences(STATE_PREF, 0).getBoolean(KEY_SHOW_WEB, false);
        String str = TabManager.currentTab().url;
        boolean equals = "about:blank".equals(str);
        SharedPreferences sharedPreferences = getSharedPreferences(SearchPref.PREF_NAME, 0);
        this.currentEngine = SearchPref.Engine.fromId(sharedPreferences.getString(SearchPref.KEY_ENGINE, SearchPref.Engine.GOOGLE.id));
        this.autoSuggestEnabled = sharedPreferences.getBoolean(SearchPref.KEY_AUTO_SUGGEST, true);
        updateSearchEngineIcon(this.currentEngine);
        this.cvSelectCountry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickProxy.launch(new Intent(IncognitoActivity.this, SelectCountryActivity.class));
            }
        });
        this.lltab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(IncognitoActivity.this, IncognitoTabActivity.class), 100);
            }
        });
        this.lltab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(IncognitoActivity.this, IncognitoTabActivity.class), 100);
            }
        });

        String str2 = IncognitoTabManager.currentTab().url;
        if (!"about:blank".equals(str2)) {
            web.loadUrl(str2);
        }
        applyProxy(ProxyData.fromPref(getSharedPreferences(PREFS, 0).getString(KEY_RAW, ProxyData.NO_PROXY_SENTINEL)));
        if (!z || equals) {
            this.rlSearchdata.setVisibility(View.VISIBLE);
            this.llBrowser.setVisibility(View.VISIBLE);
            this.rlWebShow.setVisibility(View.GONE);
        } else {
            this.rlSearchdata.setVisibility(View.GONE);
            this.llBrowser.setVisibility(View.GONE);
            this.rlWebShow.setVisibility(View.VISIBLE);
            this.edtFinalQuery.setText(str);
            web.loadUrl(str);
        }
        this.imgSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rlSearchdata.setVisibility(View.GONE);
                llBrowser.setVisibility(View.GONE);
                rlWebShow.setVisibility(View.VISIBLE);
                startSearch(edtQuery.getText().toString(), edtQuery);
            }
        });
        this.edtQuery.setInputType(16);
        this.edtQuery.setSingleLine(true);
        this.edtQuery.setImeOptions(3);
        this.edtQuery.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int i, KeyEvent keyEvent) {
                boolean z = keyEvent != null && keyEvent.getKeyCode() == 66 && keyEvent.getAction() == 0;
                if (i != 3 && i != 2 && i != 6 && !z) {
                    return false;
                }
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        rlSearchdata.setVisibility(View.GONE);
                        llBrowser.setVisibility(View.GONE);
                        rlWebShow.setVisibility(View.VISIBLE);
                        startSearch(edtQuery.getText().toString(), edtQuery);
                    }
                }, 10);
                return true;
            }
        });
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setUserAgentString(WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Version/4.0 ", ""));
        web.setLayerType(View.LAYER_TYPE_HARDWARE, (Paint) null);
        web.setWebViewClient(new InAppClient());
        web.setWebChromeClient(new SameWindowChrome(this, web));
        web.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                handleDownload(str, userAgent, contentDisposition, mimetype, contentLength);
            }
        });
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        this.drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        this.navigationView = (NavigationView) findViewById(R.id.navigation_view);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawer);
        this.imgDrawer = imageView;
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer((int) GravityCompat.START);
            }
        });
        View headerView = this.navigationView.getHeaderView(0);
        this.rlSetting = (RelativeLayout) headerView.findViewById(R.id.rlSetting);
        this.rlHistory = (RelativeLayout) headerView.findViewById(R.id.rlHistory);
        this.rlDownload = (RelativeLayout) headerView.findViewById(R.id.rlDownload);
        this.rlIncognito = (RelativeLayout) headerView.findViewById(R.id.rlIncognito);
        this.rlDesktop = (RelativeLayout) headerView.findViewById(R.id.rlDesktop);
        this.rlForward = (RelativeLayout) headerView.findViewById(R.id.rlForward);
        this.rlShare = (RelativeLayout) headerView.findViewById(R.id.rlShare);
        this.rlRate = (RelativeLayout) headerView.findViewById(R.id.rlRate);
        this.rlPolicy = (RelativeLayout) headerView.findViewById(R.id.rlPolicy);
        this.cbDesktop = (CheckBox) headerView.findViewById(R.id.cbDesktop);
        SharedPreferences sharedPreferences2 = getSharedPreferences(PREFS, 0);
        this.mobileUA = WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Version/4.0 ", "");
        boolean z2 = sharedPreferences2.getBoolean(KEY_DESKTOP, false);
        this.cbDesktop.setChecked(z2);
        applyDesktopMode(z2);
        this.cbDesktop.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull CompoundButton buttonView, boolean isChecked) {
                applyDesktopMode(isChecked);
                sharedPreferences2.edit().putBoolean(KEY_DESKTOP, isChecked).apply();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        IncognitoActivity.this.drawerLayout.closeDrawer((int) GravityCompat.START);
                    }
                }, 400);
            }
        });
        this.rlHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(IncognitoActivity.this, HistoryActivity.class));
                drawerLayout.closeDrawer((int) GravityCompat.START);
            }
        });
        this.rlDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(IncognitoActivity.this, DownloadActivity.class));
                //drawerLayout.closeDrawer((int) GravityCompat.START);
            }
        });
        this.rlIncognito.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.closeDrawer((int) GravityCompat.START);
            }
        });
        this.rlSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(IncognitoActivity.this, SettingActivity.class));
                drawerLayout.closeDrawer((int) GravityCompat.START);
            }
        });
        this.rlRate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + getPackageName())));
                } catch (ActivityNotFoundException unused) {
                    startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                }
                drawerLayout.closeDrawer((int) GravityCompat.START);
            }
        });
        this.rlShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View currentFocus = getCurrentFocus();
                if (currentFocus != null) {
                    currentFocus.clearFocus();
                }
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.TEXT", "Check out this amazing app:\n\nhttps://play.google.com/store/apps/details?id=" + getPackageName());
                startActivity(Intent.createChooser(intent, "Share App via"));
                drawerLayout.closeDrawer((int) GravityCompat.START);
            }
        });
        this.rlPolicy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View currentFocus = getCurrentFocus();
                if (currentFocus != null) {
                    currentFocus.clearFocus();
                }
                Intent intentPrivacy = new Intent(Intent.ACTION_VIEW, Uri.parse(MyApplication.PrivacyPolicy));
                intentPrivacy.setPackage("com.android.chrome");
                startActivity(intentPrivacy);
                drawerLayout.closeDrawer((int) GravityCompat.START);
            }
        });


        attachQuickSearch(this.llInsta, "Instagram");
        attachQuickSearch(this.llFB, "facebook");
        attachQuickSearch(this.llTiktok, "Tiktok");
        attachQuickSearch(this.llPinterest, "Pinterest");
        attachQuickSearch(this.llWA, "whatsapp");
        attachQuickSearch(this.llVimeo, "vimeo");
        attachQuickSearch(this.llDaily, "dailymotion");
        attachQuickSearch(this.llTwitter, "twitter");
        this.imgRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (web.getUrl() != null) {
                    web.reload();
                }
            }
        });
        if (this.autoSuggestEnabled) {
            AutoSuggestAdapter autoSuggestAdapter = new AutoSuggestAdapter(this);
            this.suggestAdapter = autoSuggestAdapter;
            this.edtQuery.setAdapter(autoSuggestAdapter);
            this.edtQuery.setThreshold(2);
            this.edtQuery.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                    edtQueryCall(adapterView, view, position, id);
                }
            });
        } else {
            this.edtQuery.setAdapter(null);
        }
        this.edtFinalQuery.setInputType(16);
        this.edtFinalQuery.setSingleLine(true);
        this.edtFinalQuery.setImeOptions(3);
        this.edtFinalQuery.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int i, KeyEvent keyEvent) {
                boolean z = keyEvent != null && keyEvent.getKeyCode() == 66 && keyEvent.getAction() == 0;
                if (i != 3 && i != 2 && i != 6 && !z) {
                    return false;
                }
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        IncognitoActivity incognitoActivity = IncognitoActivity.this;
                        incognitoActivity.startSearch(incognitoActivity.edtFinalQuery.getText().toString(), IncognitoActivity.this.edtFinalQuery);
                    }
                }, 100);
                return true;
            }
        });
    }

    
    public void edtQueryCall(AdapterView adapterView, View view, int i, long j) {
        String item = this.suggestAdapter.getItem(i);
        if (item != null) {
            this.edtQuery.setText(item);
            this.edtQuery.setSelection(item.length());
            this.rlSearchdata.setVisibility(View.GONE);
            this.llBrowser.setVisibility(View.GONE);
            this.rlWebShow.setVisibility(View.VISIBLE);
            startSearch(this.edtQuery.getText().toString(), this.edtQuery);
        }
    }

    private void attachQuickSearch(View view, String str) {
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtQuery.setText(str);
                rlSearchdata.setVisibility(View.GONE);
                llBrowser.setVisibility(View.GONE);
                rlWebShow.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        IncognitoActivity incognitoActivity = IncognitoActivity.this;
                        incognitoActivity.startSearch(incognitoActivity.edtQuery.getText().toString(), IncognitoActivity.this.edtQuery);
                    }
                }, 100);
            }
        });
    }
    
    public void startSearch(String str, EditText editText) {
        if (editText != null) {
            hideKeyboard(editText);
        }
        String trim = str.trim();
        if (trim.isEmpty()) {
            Toast.makeText(this, "Enter something to open", Toast.LENGTH_SHORT).show();
            this.rlSearchdata.setVisibility(View.VISIBLE);
            this.llBrowser.setVisibility(View.VISIBLE);
            this.rlWebShow.setVisibility(View.GONE);
            return;
        }
        String str2 = (trim.startsWith("http://") || trim.startsWith("https://")) ? trim : this.currentEngine.prefix + Uri.encode(trim);
        if (editText == this.edtQuery || this.rlWebShow.getVisibility() != View.VISIBLE) {
            this.clearOnNextPageFinished = true;
        }
        this.edtFinalQuery.setText(str2);
        this.edtQuery.setText("");
        web.stopLoading();
        web.clearHistory();
        web.clearCache(true);
        web.loadUrl("about:blank");
        if (trim.isEmpty()) {
            trim = "New tab";
        }
        IncognitoTabManager.setTitle(trim);
        ProxyData proxyData = selected;
        if (proxyData == null) {
            IncognitoTabManager.setUrl(str2);
            web.loadUrl(str2);
        } else if (!proxyData.isWorking) {
            Toast.makeText(this, "Pick a working proxy first!", Toast.LENGTH_SHORT).show();
        } else {
            this.ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    web.loadUrl(str2);
                }
            }, 1000);
        }
    }

    
    public void applyProxy(ProxyData proxyData) {
        OkHttpClient okHttpClient = null;
        selected = proxyData.noProxy ? null : proxyData;
        if (!proxyData.noProxy) {
            okHttpClient = SelectCountryActivity.buildProxyClient(proxyData);
        }
        okProxy = okHttpClient;
        ImageView imageView = this.imgFlag;
        boolean z = proxyData.noProxy;
        imageView.setImageResource(R.drawable.ic_flagindia);
        getSharedPreferences(PREFS, 0).edit().putString(KEY_RAW, proxyData.toPref()).apply();
        if (web.getUrl() != null && !web.getUrl().isEmpty()) {
            web.reload();
        }
    }

    
    public static Map<String, String> toSingleMap(Headers headers) {
        HashMap hashMap = new HashMap();
        for (String next : headers.names()) {
            if (!"Set-Cookie".equalsIgnoreCase(next)) {
                hashMap.put(next, TextUtils.join(", ", headers.values(next)));
            }
        }
        return hashMap;
    }

    private class InAppClient extends WebViewClient {
        private final AtomicBoolean retried;

        private InAppClient() {
            this.retried = new AtomicBoolean(false);
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest webResourceRequest) {
            String str;
            if (IncognitoActivity.okProxy == null || IncognitoActivity.selected == null || !IncognitoActivity.selected.isWorking) {
                return super.shouldInterceptRequest(webView, webResourceRequest);
            }
            if (!"GET".equalsIgnoreCase(webResourceRequest.getMethod())) {
                return super.shouldInterceptRequest(webView, webResourceRequest);
            }
            String uri = webResourceRequest.getUrl().toString();
            Log.d("Selectproxy", "→ " + uri + "  via  " + IncognitoActivity.selected.host + ":" + IncognitoActivity.selected.port);
            try {
                Request.Builder url = new Request.Builder().url(webResourceRequest.getUrl().toString());
                for (Map.Entry next : webResourceRequest.getRequestHeaders().entrySet()) {
                    url.addHeader((String) next.getKey(), (String) next.getValue());
                }
                url.header("Accept-Encoding", "identity");
                Response execute = IncognitoActivity.okProxy.newCall(url.build()).execute();
                CookieManager instance = CookieManager.getInstance();
                for (String cookie : execute.headers("Set-Cookie")) {
                    instance.setCookie(webResourceRequest.getUrl().getHost(), cookie);
                }
                instance.flush();
                String header = execute.header("content-type", "");
                String trim = header.isEmpty() ? "application/octet-stream" : header.split(";", 2)[0].trim();
                if (!uri.contains("googlevideo.com") && !uri.contains("video") && !uri.endsWith(".mp4") && !uri.endsWith(".m3u8")) {
                    if (!uri.endsWith(".ts")) {
                        int code = execute.code();
                        if (code == 204) {
                            str = "No Content";
                        } else if (code == 206) {
                            str = "Partial Content";
                        } else if (code == 304) {
                            str = "Not Modified";
                        } else if (code == 500) {
                            str = "Internal Server Error";
                        } else if (code == 301) {
                            str = "Moved Permanently";
                        } else if (code == 302) {
                            str = "Found";
                        } else if (code == 400) {
                            str = "Bad Request";
                        } else if (code == 401) {
                            str = "Unauthorized";
                        } else if (code == 403) {
                            str = "Forbidden";
                        } else if (code != 404) {
                            str = "OK";
                            switch (code) {
                                case 201:
                                    str = "Created";
                                    break;
                                case 202:
                                    str = "Accepted";
                                    break;
                            }
                        } else {
                            str = "Not Found";
                        }
                        return new WebResourceResponse(trim, (String) null, code, str, IncognitoActivity.toSingleMap(execute.headers()), execute.body().byteStream());
                    }
                }
                return super.shouldInterceptRequest(webView, webResourceRequest);
            } catch (Exception unused) {
                return super.shouldInterceptRequest(webView, webResourceRequest);
            }
        }

        @Override
        public void onReceivedError(WebView webView, WebResourceRequest webResourceRequest, WebResourceError webResourceError) {
            super.onReceivedError(webView, webResourceRequest, webResourceError);
            String uri = webResourceRequest.getUrl().toString();
            webResourceError.getErrorCode();
            if ((uri.endsWith(".mp4") || uri.contains("video") || uri.endsWith(".m3u8") || uri.endsWith(".ts") || uri.contains("googlevideo.com")) && !this.retried.getAndSet(true)) {
                Objects.requireNonNull(webView);
                webView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        webView.reload();
                    }
                }, 1200);
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
            String scheme = webResourceRequest.getUrl().getScheme();
            webResourceRequest.getUrl();
            return !"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme);
        }

        @Override
        public void onReceivedError(WebView webView, int i, String str, String str2) {
            super.onReceivedError(webView, i, str, str2);
            if (i == -8 || i == -6) {
                webView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        int indexOf;
                        if (IncognitoActivity.selected != null && SelectCountryActivity.proxies.size() >= 2 && (indexOf = SelectCountryActivity.proxies.indexOf(IncognitoActivity.selected)) != -1) {
                            int i = 1;
                            while (i < SelectCountryActivity.proxies.size()) {
                                ProxyData proxyData = SelectCountryActivity.proxies.get((indexOf + i) % SelectCountryActivity.proxies.size());
                                if (proxyData.noProxy || !proxyData.isWorking) {
                                    i++;
                                } else {
                                    IncognitoActivity.this.applyProxy(proxyData);
                                    webView.loadUrl(str2);
                                    return;
                                }
                            }
                        }
                    }
                }, 2000);


            }
        }

        @Override
        public void onReceivedSslError(WebView webView, final SslErrorHandler sslErrorHandler, SslError sslError) {
            AlertDialog.Builder builder = new AlertDialog.Builder(IncognitoActivity.this);
            builder.setTitle((CharSequence) "SSL Certificate Error");
            builder.setMessage((CharSequence) "The website's security certificate is not trusted. Do you want to continue anyway?");
            builder.setPositiveButton((CharSequence) "Continue", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    sslErrorHandler.proceed();
                }
            });
            builder.setNegativeButton((CharSequence) "Cancel", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    sslErrorHandler.cancel();
                }
            });
            builder.create().show();
        }

        @Override
        public void onPageFinished(WebView webView, String str) {
            super.onPageFinished(webView, str);
            if (IncognitoActivity.this.desktopMode) {
                Objects.requireNonNull(webView);
                webView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        webView.zoomOut();
                    }
                }, 50);
            }
            if (IncognitoActivity.this.clearOnNextPageFinished) {
                webView.clearHistory();
                IncognitoActivity.this.clearOnNextPageFinished = false;
            }
            IncognitoTabManager.setUrl(str);
            IncognitoTabManager.captureAndSaveThumb(IncognitoActivity.web);
            IncognitoActivity.this.edtFinalQuery.setText(str);
            if (IncognitoActivity.this.skipNextSave) {
                IncognitoActivity.this.skipNextSave = false;
                return;
            }
            webView.evaluateJavascript("(function(){  var css='*{filter:none!important;-webkit-filter:none!important;}';  var s=document.createElement('style');  s.type='text/css';  s.appendChild(document.createTextNode(css));  document.head.appendChild(s);})();", (ValueCallback) null);
            webView.evaluateJavascript("(function(){  var btn=document.querySelector('.vjs-big-play-button,                                 .bigPlayButton,                                 .btnPlay');  if(btn){ btn.click(); }})();", (ValueCallback) null);
        }
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 100 && i2 == -1) {
            IncognitoTabManager.select((intent == null || !intent.hasExtra("tab")) ? IncognitoTabManager.current() : intent.getIntExtra("tab", IncognitoTabManager.current()));
            updateTabIndicator();
            String str = IncognitoTabManager.currentTab().url;
            if (!"about:blank".equals(str)) {
                this.rlSearchdata.setVisibility(View.GONE);
                this.llBrowser.setVisibility(View.GONE);
                this.rlWebShow.setVisibility(View.VISIBLE);
                web.loadUrl(str);
                return;
            }
            this.rlSearchdata.setVisibility(View.VISIBLE);
            this.llBrowser.setVisibility(View.VISIBLE);
            this.rlWebShow.setVisibility(View.GONE);
        }
    }


    private void hideKeyboard(View view) {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService("input_method");
        if (inputMethodManager != null) {
            inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    private void applyDesktopMode(boolean z) {
        WebSettings settings = web.getSettings();
        settings.setSupportZoom(z);
        settings.setBuiltInZoomControls(z);
        settings.setDisplayZoomControls(false);
        if (z) {
            settings.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(true);
            DisplayMetrics displayMetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            web.setInitialScale((int) ((((float) displayMetrics.widthPixels) * 100.0f) / 1200.0f));
        } else {
            settings.setUserAgentString(WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Version/4.0 ", ""));
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(false);
            settings.setSupportZoom(false);
            settings.setBuiltInZoomControls(false);
            settings.setDisplayZoomControls(false);
        }
        if (web.getUrl() != null && !web.getUrl().isEmpty()) {
            web.reload();
        }
    }

    
    public void IncognitoActivityActivityResultCallbackCall(ActivityResult activityResult) {
        ProxyData proxyData;
        if (activityResult.getResultCode() == -1 && activityResult.getData() != null && (proxyData = (ProxyData) activityResult.getData().getParcelableExtra("proxy")) != null) {
            applyProxy(proxyData);
        }
    }

    
    public void handleDownload(String str, String str2, String str3, String str4, long j) {
        if (ActivityCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 42);
            this.pendingDownload = new Pending(str, str2, str3, str4);
            return;
        }
        getSharedPreferences("downloads", 0).edit().putLong(String.valueOf(((DownloadManager) getSystemService("download")).enqueue(new DownloadManager.Request(Uri.parse(str)).addRequestHeader("User-Agent", str2).addRequestHeader("Cookie", CookieManager.getInstance().getCookie(str)).setMimeType(str4).setNotificationVisibility(1).setAllowedOverMetered(true).setAllowedOverRoaming(true).setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(str, str3, str4)))), System.currentTimeMillis()).apply();
    }

    private static class Pending {
        String contentDisposition;
        String mimeType;
        String url;
        String userAgent;

        Pending(String str, String str2, String str3, String str4) {
            this.url = str;
            this.userAgent = str2;
            this.contentDisposition = str3;
            this.mimeType = str4;
        }
    }

    @SuppressLint("GestureBackNavigation")
    public void onBackPressed() {
        if (this.drawerLayout.isDrawerOpen((int) GravityCompat.START)) {
            this.drawerLayout.closeDrawer((int) GravityCompat.START);
        } else if (this.rlWebShow.getVisibility() != View.VISIBLE) {
            if (!IncognitoTabManager.currentTab().url.equals("about:blank")) {
                this.rlSearchdata.setVisibility(View.VISIBLE);
                this.rlWebShow.setVisibility(View.GONE);
                this.edtQuery.requestFocus();
            }
            super.onBackPressed();
        } else if (web.canGoBack()) {
            this.skipNextSave = true;
            web.goBack();
        } else {
            this.rlSearchdata.setVisibility(View.VISIBLE);
            this.llBrowser.setVisibility(View.VISIBLE);
            this.rlWebShow.setVisibility(View.GONE);
            web.stopLoading();
            web.clearHistory();
            this.edtQuery.requestFocus();
            TabManager.resetCurrentTab();
            TabManager.setUrl("about:blank");
            TabManager.setTitle("New tab");
            getSharedPreferences(STATE_PREF, 0).edit().putBoolean(KEY_SHOW_WEB, false).apply();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        getSharedPreferences(STATE_PREF, 0).edit().putBoolean(KEY_SHOW_WEB, this.rlWebShow.getVisibility() == View.VISIBLE && web.getUrl() != null && !"about:blank".equals(web.getUrl())).apply();
    }

    @Override
    public void onResume() {
        super.onResume();
        View currentFocus = getCurrentFocus();
        if (currentFocus != null) {
            currentFocus.clearFocus();
            ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
        }
        this.currentEngine = SearchPref.Engine.fromId(getSharedPreferences(SearchPref.PREF_NAME, 0).getString(SearchPref.KEY_ENGINE, SearchPref.Engine.GOOGLE.id));
        updateAutoSuggestState();
        updateSearchEngineIcon(this.currentEngine);
    }

    static class ClassWEB4 {
        static final int[] UtilsSaveDataSearchPrefEngine;

        static {
            int[] iArr = new int[SearchPref.Engine.values().length];
            UtilsSaveDataSearchPrefEngine = iArr;
            iArr[SearchPref.Engine.GOOGLE.ordinal()] = 1;
            UtilsSaveDataSearchPrefEngine[SearchPref.Engine.DUCKDUCKGO.ordinal()] = 2;
            UtilsSaveDataSearchPrefEngine[SearchPref.Engine.BING.ordinal()] = 3;
            try {
                UtilsSaveDataSearchPrefEngine[SearchPref.Engine.YAHOO.ordinal()] = 4;
            } catch (NoSuchFieldError unused) {
            }
        }
    }

    private void updateSearchEngineIcon(SearchPref.Engine engine) {
        int i;
        int i2 = ClassWEB4.UtilsSaveDataSearchPrefEngine[engine.ordinal()];
        if (i2 == 1) {
            i = R.drawable.ic_google;
        } else if (i2 == 2) {
            i = R.drawable.ic_duckduckgo;
        } else if (i2 == 3) {
            i = R.drawable.ic_bing;
        } else if (i2 != 4) {
            i = R.drawable.ic_google;
        } else {
            i = R.drawable.ic_yahoo;
        }
        this.imgGoogle.setImageResource(i);
    }

    private void updateAutoSuggestState() {
        boolean z = getSharedPreferences(SearchPref.PREF_NAME, 0).getBoolean(SearchPref.KEY_AUTO_SUGGEST, true);
        if (z != this.autoSuggestEnabled) {
            this.autoSuggestEnabled = z;
            if (z) {
                if (this.suggestAdapter == null) {
                    this.suggestAdapter = new AutoSuggestAdapter(this);
                }
                this.edtQuery.setAdapter(this.suggestAdapter);
                this.edtQuery.setThreshold(2);
                this.edtQuery.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                        edtQueryCall2(adapterView, view, position, id);
                    }
                });
                return;
            }
            this.edtQuery.setAdapter(null);
        }
    }

    
    public void edtQueryCall2(AdapterView adapterView, View view, int i, long j) {
        String item = this.suggestAdapter.getItem(i);
        if (item != null) {
            this.edtQuery.setText(item);
            this.edtQuery.setSelection(item.length());
            this.rlSearchdata.setVisibility(View.GONE);
            this.llBrowser.setVisibility(View.GONE);
            this.rlWebShow.setVisibility(View.VISIBLE);
            startSearch(this.edtQuery.getText().toString(), this.edtQuery);
        }
    }

}
