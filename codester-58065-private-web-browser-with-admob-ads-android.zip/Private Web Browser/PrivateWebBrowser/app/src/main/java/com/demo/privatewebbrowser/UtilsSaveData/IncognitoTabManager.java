package com.demo.privatewebbrowser.UtilsSaveData;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.webkit.WebView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public final class IncognitoTabManager {
    private static final Gson GSON = new Gson();
    private static final String KEY = "inco_tabs_json";
    private static final String PREF = "inco_tabs_pref";
    private static SharedPreferences SP;
    private static final List<Tab> TABS = new ArrayList();
    private static int current = 0;
    private static File thumbDir;

    public static class Tab {
        public String thumb = null;
        public String title = "New tab";
        public String url = "about:blank";
    }

    public static void init(Context context) {
        if (SP == null) {
            SP = context.getSharedPreferences(PREF, 0);
            File file = new File(context.getCacheDir(), "tab_thumbs");
            thumbDir = file;
            file.mkdirs();
            loadFromDisk();
            List<Tab> list = TABS;
            if (list.isEmpty()) {
                list.add(new Tab());
            }
        }
    }

    public static void setTitle(String str) {
        currentTab().title = str;
        save();
    }

    public static int size() {
        return TABS.size();
    }

    public static int current() {
        return current;
    }

    public static Tab currentTab() {
        return TABS.get(current);
    }

    public static Tab get(int i) {
        return TABS.get(i);
    }

    public static void select(int i) {
        current = i;
        save();
    }

    public static void addTab() {
        List<Tab> list = TABS;
        list.add(new Tab());
        current = list.size() - 1;
        save();
    }

    public static void close(int i) {
        List<Tab> list = TABS;
        Tab remove = list.remove(i);
        if (remove.thumb != null) {
            new File(remove.thumb).delete();
        }
        if (current >= list.size()) {
            current = Math.max(0, list.size() - 1);
        }
        if (list.isEmpty()) {
            list.add(new Tab());
        }
        save();
    }

    public static void setUrl(String str) {
        currentTab().url = str;
        save();
    }

    public static void captureAndSaveThumb(WebView webView) {
        FileOutputStream fileOutputStream;
        int width = webView.getWidth();
        int height = webView.getHeight();
        if (width != 0 && height != 0) {
            Bitmap createBitmap = Bitmap.createBitmap(webView.getWidth(), webView.getHeight(), Bitmap.Config.RGB_565);
            webView.draw(new Canvas(createBitmap));
            try {
                File createTempFile = File.createTempFile("tab_", ".jpg", webView.getContext().getCacheDir());
                fileOutputStream = new FileOutputStream(createTempFile);
                createBitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
                fileOutputStream.close();
                Tab currentTab = currentTab();
                if (currentTab.thumb != null) {
                    new File(currentTab.thumb).delete();
                }
                currentTab.thumb = createTempFile.getAbsolutePath();
                save();
                return;
            } catch (IOException unused) {
                return;
            } catch (Throwable th) {
                th.addSuppressed(th);
            }
        } else {
            return;
        }
    }

    private static void save() {
        SP.edit().putString(KEY, GSON.toJson((Object) TABS)).putInt("current", current).apply();
    }

    private static void loadFromDisk() {
        String string = SP.getString(KEY, (String) null);
        current = SP.getInt("current", 0);
        if (string != null) {
            Type type = new TypeToken<ArrayList<Tab>>() {
            }.getType();
            try {
                List<Tab> list = TABS;
                list.clear();
                list.addAll((Collection) GSON.fromJson(string, type));
            } catch (Exception unused) {
                TABS.clear();
            }
        }
    }
}
