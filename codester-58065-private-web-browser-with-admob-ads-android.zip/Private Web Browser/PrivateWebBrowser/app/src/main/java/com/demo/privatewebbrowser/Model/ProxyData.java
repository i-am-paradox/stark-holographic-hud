package com.demo.privatewebbrowser.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class ProxyData implements Parcelable {
    public static final Creator<ProxyData> CREATOR = new Creator<ProxyData>() {
        @Override
        public ProxyData createFromParcel(Parcel parcel) {
            return new ProxyData(parcel);
        }

        @Override
        public ProxyData[] newArray(int i) {
            return new ProxyData[i];
        }
    };
    public static final String NO_PROXY_SENTINEL = "NO_PROXY_INDIA";
    public String country;
    public String countryCode;
    public String host;
    public boolean isWorking;
    public boolean noProxy;
    public String pass;
    public int port;
    public String user;

    public int describeContents() {
        return 0;
    }

    public ProxyData() {
        this.noProxy = true;
        this.pass = "";
        this.user = "";
        this.host = "";
        this.port = 0;
        this.isWorking = true;
        this.country = "India";
        this.countryCode = "in";
    }

    public ProxyData(String str) {
        this.country = null;
        this.countryCode = null;
        this.noProxy = false;
        String[] split = str.trim().split(":");
        this.host = split[0];
        this.port = Integer.parseInt(split[1]);
        if (split.length >= 4) {
            this.user = split[2];
            this.pass = split[3];
        } else {
            this.user = "";
            this.pass = "";
        }
        this.country = null;
        this.countryCode = null;
    }

    protected ProxyData(Parcel parcel) {
        this.country = null;
        this.countryCode = null;
        boolean z = true;
        this.noProxy = parcel.readByte() != 0;
        this.host = parcel.readString();
        this.user = parcel.readString();
        this.pass = parcel.readString();
        this.port = parcel.readInt();
        this.isWorking = parcel.readByte() == 0 ? false : z;
        this.country = parcel.readString();
        this.countryCode = parcel.readString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte(this.noProxy ? (byte) 1 : 0);
        parcel.writeString(this.host);
        parcel.writeString(this.user);
        parcel.writeString(this.pass);
        parcel.writeInt(this.port);
        parcel.writeByte(this.isWorking ? (byte) 1 : 0);
        parcel.writeString(this.country);
        parcel.writeString(this.countryCode);
    }

    public String toPref() {
        if (this.noProxy) {
            return NO_PROXY_SENTINEL;
        }
        StringBuilder append = new StringBuilder().append(this.host).append(":").append(this.port).append(":").append(this.user).append(":").append(this.pass).append(":");
        String str = this.countryCode;
        String str2 = "";
        if (str == null) {
            str = str2;
        }
        StringBuilder append2 = append.append(str).append(":");
        String str3 = this.country;
        if (str3 != null) {
            str2 = str3;
        }
        return append2.append(str2).toString();
    }

    public static ProxyData fromPref(String str) {
        if (str == null || str.equals(NO_PROXY_SENTINEL)) {
            return new ProxyData();
        }
        String[] split = str.split(":", -1);
        ProxyData proxyData = new ProxyData();
        proxyData.noProxy = false;
        try {
            proxyData.host = split[0];
            proxyData.port = Integer.parseInt(split[1]);
            String str2 = "";
            proxyData.user = split.length > 2 ? split[2] : str2;
            proxyData.pass = split.length > 3 ? split[3] : str2;
            proxyData.countryCode = split.length > 4 ? split[4] : str2;
            if (split.length > 5) {
                str2 = split[5];
            }
            proxyData.country = str2;
            proxyData.isWorking = true;
            return proxyData;
        } catch (Exception unused) {
            return new ProxyData();
        }
    }

    public String toString() {
        if (this.noProxy) {
            return "Quality : High";
        }
        return this.host + ":" + this.port + (this.isWorking ? " ✓" : " ✗");
    }
}
