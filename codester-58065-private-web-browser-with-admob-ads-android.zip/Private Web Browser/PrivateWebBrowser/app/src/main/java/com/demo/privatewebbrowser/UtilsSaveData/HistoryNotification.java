package com.demo.privatewebbrowser.UtilsSaveData;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import com.demo.privatewebbrowser.Activity.HomeBrowserActivity;
import com.demo.privatewebbrowser.R;

public final class HistoryNotification {
    public static final String CHANNEL_ID = "history_channel";
    public static final String EXTRA_FROM_NOTIFICATION = "from_notification";
    public static final int NOTIF_ID = 1001;

    public static void show(Context context) {
        if (!HistoryStore.isEmpty(context)) {
            if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, "android.permission.POST_NOTIFICATIONS") == 0) {
                createChannel(context);
                NotificationManagerCompat.from(context).notify(1001, new NotificationCompat.Builder(context, CHANNEL_ID).setSmallIcon(R.drawable.logo).setContentTitle("Clear browsing history").setContentText("Tap to delete").setPriority(0).setAutoCancel(false).setContentIntent(PendingIntent.getActivity(context, 0, new Intent(context, HomeBrowserActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(EXTRA_FROM_NOTIFICATION, true), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE)).build());
            }
        }
    }

    public static void tryShowIfHistoryExists(Context context) {
        if (!HistoryStore.isEmpty(context) && !AppStateManager.isInForeground) {
            show(context);
        }
    }

    private static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(NotificationManager.class);
            if (notificationManager.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, "History", NotificationManager.IMPORTANCE_DEFAULT);
                notificationChannel.setDescription("Notifications related to browsing history");
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }
    }

    public static void cancel(Context context) {
        NotificationManagerCompat.from(context).cancel(1001);
    }

    private HistoryNotification() {
    }
}
