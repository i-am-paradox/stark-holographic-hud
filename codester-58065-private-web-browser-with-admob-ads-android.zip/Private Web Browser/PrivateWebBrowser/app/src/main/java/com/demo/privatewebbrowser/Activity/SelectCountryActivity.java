package com.demo.privatewebbrowser.Activity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.demo.privatewebbrowser.Adapter.NewProxyAdapter;
import com.demo.privatewebbrowser.Model.ProxyData;
import com.demo.privatewebbrowser.R;
import com.demo.privatewebbrowser.ads.AdsCommon;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import okhttp3.ConnectionPool;
import okhttp3.OkHttpClient;
import okhttp3.Request;


public class SelectCountryActivity extends AppCompatActivity implements NewProxyAdapter.OnProxyClick {
    private static final String KEY_RAW = "selected_raw";
    private static final String PREFS = "proxy_prefs";
    public static final List<ProxyData> proxies = new ArrayList();
    private NewProxyAdapter adapter;
    private ExecutorService exec;
    RecyclerView rvProxy;
    private int selectedPos = 0;
    private Handler ui;

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        setContentView(R.layout.activity_select_country);

        applyDisplayCutouts();


        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) findViewById(R.id.Admob_Banner_Frame);
        LinearLayout adContainer = (LinearLayout) findViewById(R.id.banner_container);
        FrameLayout qureka = (FrameLayout) findViewById(R.id.qureka);
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(1024);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.black));
        int i = 1;
        WindowCompat.setDecorFitsSystemWindows(window, true);
        int i2 = 0;



        this.exec = Executors.newFixedThreadPool(4);
        this.ui = new Handler(Looper.getMainLooper());
        this.rvProxy = (RecyclerView) findViewById(R.id.rvProxy);
        if (!isInternetAvailable()) {
            showNoInternetDialog();
        } else {
            //loadProxyList();
        }
        List<ProxyData> list = proxies;
        if (list.isEmpty()) {
            //loadProxyList();
            list.add(0, new ProxyData());
        }
        String string = getSharedPreferences(PREFS, 0).getString(KEY_RAW, (String) null);
        if (string != null) {
            while (true) {
                List<ProxyData> list2 = proxies;
                if (i2 >= list2.size()) {
                    break;
                }
                if (list2.get(i2).toPref().equals(string)) {
                    this.selectedPos = i2;
                }
                i2++;
            }
        }
        this.adapter = new NewProxyAdapter(proxies, this.selectedPos, this);
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rvProxy);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(this.adapter);
        this.adapter.setSelected(this.selectedPos);
        recyclerView.scrollToPosition(this.selectedPos);
        while (true) {
            List<ProxyData> list3 = proxies;
            if (i < list3.size()) {
                testProxy(list3.get(i), new SelectCountryActivityConsumer1(this, i));
                i++;
            } else {
                findViewById(R.id.imgBack).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onBackPressed();
                    }
                });
                return;
            }
        }
    }

    
    public void SelectCountryActivityConsumer1Call(int i, Boolean bool) {
        this.adapter.notifyItemChanged(i);
    }

    


    private void showNoInternetDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.dialog_no_internetproxy);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().setLayout(-1, -1);
            dialog.getWindow().setGravity(17);
        }
        ((TextView) dialog.findViewById(R.id.txtOK)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                onBackPressed();
            }
        });
        dialog.show();
    }

    


    @Override
    public void onClick(ProxyData proxyData, int i) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.dialog_proxyenable);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().setLayout(-1, -1);
            dialog.getWindow().setGravity(17);
        }
        ((TextView) dialog.findViewById(R.id.txtOK)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                if (!proxyData.isWorking) {
                    Toast.makeText(SelectCountryActivity.this, "❌ Proxy expired or not working: " + proxyData.host + ":" + proxyData.port, Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(SelectCountryActivity.this, "✅ Proxy is working: " + proxyData.host, Toast.LENGTH_SHORT).show();
                SelectCountryActivity.this.getSharedPreferences(SelectCountryActivity.PREFS, 0).edit().putString(SelectCountryActivity.KEY_RAW, proxyData.toPref()).apply();
                Intent intent = new Intent();
                intent.putExtra("proxy", proxyData);
                SelectCountryActivity.this.setResult(-1, intent);
                SelectCountryActivity.this.finish();
            }
        });

        dialog.show();
    }

    public static OkHttpClient buildProxyClient(ProxyData proxyData) {
        OkHttpClient.Builder connectionPool = new OkHttpClient.Builder().proxy(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyData.host, proxyData.port))).connectTimeout(20, TimeUnit.SECONDS).readTimeout(0, TimeUnit.SECONDS).writeTimeout(0, TimeUnit.SECONDS).retryOnConnectionFailure(true).connectionPool(new ConnectionPool(8, 5, TimeUnit.MINUTES));
        if (!proxyData.user.isEmpty() && !proxyData.pass.isEmpty()) {
            connectionPool.proxyAuthenticator(new SelectCountryActivityAuthenticator(proxyData));
        }
        return connectionPool.build();
    }

    private void testProxy(ProxyData proxyData, Consumer<Boolean> consumer) {
        this.exec.submit(new Runnable() {
            @Override
            public void run() {
                boolean z = false;
                try {
                    if (buildProxyClient(proxyData).newCall(new Request.Builder().url("https://clients3.google.com/generate_204").build()).execute().code() == 204) {
                        z = true;
                    }
                } catch (Exception unused) {
                }
                proxyData.isWorking = z;
                boolean finalZ = z;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        consumer.accept(finalZ);
                    }
                });
            }
        });
    }


    private void showProxyOffDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.dialog_proxy_disabled);
        dialog.setCancelable(false);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().setLayout(-1, -1);
        }
        ((TextView) dialog.findViewById(R.id.tvMessage)).setText("Proxy not available right now.\nPlease try again later.");
        ((TextView) dialog.findViewById(R.id.txtOK)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finish();
            }
        });
        dialog.show();
    }

    private boolean isInternetAvailable() {
        NetworkInfo activeNetworkInfo;
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService("connectivity");
        if (connectivityManager == null || (activeNetworkInfo = connectivityManager.getActiveNetworkInfo()) == null || !activeNetworkInfo.isConnected()) {
            return false;
        }
        return true;
    }

    @SuppressLint("GestureBackNavigation")
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

}
