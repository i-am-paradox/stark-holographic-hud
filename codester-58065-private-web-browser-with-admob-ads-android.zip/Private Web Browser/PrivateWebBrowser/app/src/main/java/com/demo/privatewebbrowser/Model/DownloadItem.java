package com.demo.privatewebbrowser.Model;

public class DownloadItem {
    public long id;
    public String localUri;
    public int progress;
    public int status;
    public String title;

    public DownloadItem(long j) {
        this.id = j;
        this.title = "";
        this.status = 0;
        this.progress = -1;
        this.localUri = null;
    }

    public DownloadItem(long j, String str, int i, int i2, String str2) {
        this.id = j;
        this.title = str;
        this.status = i;
        this.progress = i2;
        this.localUri = str2;
    }
}
