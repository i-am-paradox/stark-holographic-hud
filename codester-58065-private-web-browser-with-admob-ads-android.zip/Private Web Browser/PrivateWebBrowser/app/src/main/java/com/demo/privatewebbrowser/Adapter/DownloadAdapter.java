package com.demo.privatewebbrowser.Adapter;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;
import com.demo.privatewebbrowser.Activity.DownloadActivity;
import com.demo.privatewebbrowser.Model.DownloadItem;
import com.demo.privatewebbrowser.R;
import java.io.File;
import java.util.List;

public class DownloadAdapter extends RecyclerView.Adapter<DownloadAdapter.Holder> {
    private final Context ctx;
    private final DownloadManager dm;
    private final List<DownloadItem> items;

    public DownloadAdapter(Context context, List<DownloadItem> list) {
        this.ctx = context;
        this.items = list;
        this.dm = (DownloadManager) context.getSystemService("download");
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_download, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(Holder holder, int i) {
        DownloadItem downloadItem = this.items.get(i);
        holder.txtName.setText((downloadItem.title == null || downloadItem.title.isEmpty()) ? "…" : downloadItem.title);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFile(downloadItem);
            }
        });
        holder.imgClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteItem(downloadItem, holder.getAdapterPosition());
            }
        });

    }


    @Override
    public int getItemCount() {
        return this.items.size();
    }


    private void openFile(DownloadItem downloadItem) {
        if (downloadItem.localUri != null) {
            Uri uriFor = uriFor(downloadItem.localUri);
            String type = this.ctx.getContentResolver().getType(uriFor);
            Intent intent = new Intent("android.intent.action.VIEW");
            if (type == null) {
                type = "*/*";
            }
            this.ctx.startActivity(Intent.createChooser(intent.setDataAndType(uriFor, type).setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Open with"));
        }
    }

    private Uri uriFor(String str) {
        Uri parse = Uri.parse(str);
        if ("content".equals(parse.getScheme())) {
            return parse;
        }
        return FileProvider.getUriForFile(this.ctx, this.ctx.getPackageName() + ".provider", new File(parse.getPath()));
    }

    private String guessMime(Uri uri) {
        String fileExtensionFromUrl = MimeTypeMap.getFileExtensionFromUrl(uri.toString());
        if (fileExtensionFromUrl == null) {
            return "*/*";
        }
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtensionFromUrl.toLowerCase());
    }

    private void deleteItem(DownloadItem downloadItem, int i) {
        this.items.remove(i);
        notifyItemRemoved(i);
        this.ctx.getSharedPreferences("downloads", 0).edit().remove(String.valueOf(downloadItem.id)).apply();
        Context context = this.ctx;
        if (context instanceof DownloadActivity) {
            ((DownloadActivity) context).updateEmptyState();
        }
    }

    static class Holder extends RecyclerView.ViewHolder {
        final ImageView imgClose;
        final ProgressBar progress;
        final TextView txtName;

        Holder(View view) {
            super(view);
            this.txtName = (TextView) view.findViewById(R.id.txtFileName);
            this.progress = (ProgressBar) view.findViewById(R.id.progressBar);
            this.imgClose = (ImageView) view.findViewById(R.id.imgClose);
        }
    }
}
