package com.demo.privatewebbrowser.UtilsSaveData;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

public class AppStateManager implements Application.ActivityLifecycleCallbacks {
    public static boolean isInForeground = false;
    private static int started;

    @Override
    public void onActivityCreated(Activity activity, Bundle bundle) {
    }

    @Override
    public void onActivityDestroyed(Activity activity) {
    }

    @Override
    public void onActivityPaused(Activity activity) {
    }

    @Override
    public void onActivityResumed(Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    @Override
    public void onActivityStarted(Activity activity) {
        started++;
        isInForeground = true;
        HistoryNotification.cancel(activity.getApplicationContext());
    }

    @Override
    public void onActivityStopped(Activity activity) {
        int i = started - 1;
        started = i;
        if (i == 0) {
            isInForeground = false;
            HistoryNotification.tryShowIfHistoryExists(activity.getApplicationContext());
        }
    }
}
