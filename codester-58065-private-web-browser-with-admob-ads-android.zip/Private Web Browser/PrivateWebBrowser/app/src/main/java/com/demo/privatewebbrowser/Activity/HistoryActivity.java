package com.demo.privatewebbrowser.Activity;

import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.demo.privatewebbrowser.Adapter.HistoryAdapter;
import com.demo.privatewebbrowser.R;
import com.demo.privatewebbrowser.UtilsSaveData.HistoryNotification;
import com.demo.privatewebbrowser.UtilsSaveData.HistoryStore;
import com.demo.privatewebbrowser.UtilsSaveData.TabManager;
import com.demo.privatewebbrowser.ads.AdsCommon;

import java.util.ArrayList;
import java.util.Collections;

public class HistoryActivity extends AppCompatActivity {
    private HistoryAdapter adapter;
    ImageView imgBack;
    ImageView imgDelete;
    LinearLayout llNoData;
    private RecyclerView rvHistory;
    TextView txtNoData;

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        setContentView(R.layout.activity_history);

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) findViewById(R.id.Admob_Banner_Frame);
        LinearLayout adContainer = (LinearLayout) findViewById(R.id.banner_container);
        FrameLayout qureka = (FrameLayout) findViewById(R.id.qureka);
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);

        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(1024);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.black));
        WindowCompat.setDecorFitsSystemWindows(window, true);

        this.rvHistory = (RecyclerView) findViewById(R.id.rvHistory);
        this.imgBack = (ImageView) findViewById(R.id.imgBack);
        this.imgDelete = (ImageView) findViewById(R.id.imgDelete);
        this.txtNoData = (TextView) findViewById(R.id.txtNoData);
        this.llNoData = (LinearLayout) findViewById(R.id.llNoData);
        this.rvHistory.setLayoutManager(new LinearLayoutManager(this));
        HistoryAdapter historyAdapter = new HistoryAdapter(this, HistoryStore.getAll(this));
        this.adapter = historyAdapter;
        this.rvHistory.setAdapter(historyAdapter);
        updateEmptyState();
        this.rvHistory.scrollToPosition(0);
        this.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        this.imgDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showClearDialog();
            }
        });
        if (getIntent().getBooleanExtra(HistoryNotification.EXTRA_FROM_NOTIFICATION, false)) {
            showClearDialog();
        }
    }

    private void showClearDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.delete_history_layout);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().setLayout(-1, -1);
            dialog.getWindow().setGravity(17);
        }
        ((TextView) dialog.findViewById(R.id.txtNo)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        ((TextView) dialog.findViewById(R.id.txtYes)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                HistoryActivity.this.clearHistoryAndUpdateUI();
            }
        });
        dialog.show();
    }

    public void clearHistoryAndUpdateUI() {
        HistoryStore.clear(this);
        TabManager.resetTabs(new ArrayList());
        this.adapter.updateData(Collections.emptyList());
        this.rvHistory.scrollToPosition(0);
        updateEmptyState();
        HistoryNotification.cancel(this);
        Toast.makeText(this, "History cleared.", Toast.LENGTH_SHORT).show();
    }

    public void updateEmptyState() {
        if (this.adapter.getItemCount() == 0) {
            this.llNoData.setVisibility(View.VISIBLE);
            this.rvHistory.setVisibility(View.GONE);
            this.imgDelete.setVisibility(View.GONE);
            return;
        }
        this.llNoData.setVisibility(View.GONE);
        this.rvHistory.setVisibility(View.VISIBLE);
        this.imgDelete.setVisibility(View.VISIBLE);
    }

    @Override
    public void onResume() {
        super.onResume();
        HistoryAdapter historyAdapter = this.adapter;
        if (historyAdapter != null) {
            historyAdapter.updateData(HistoryStore.getAll(this));
            this.rvHistory.scrollToPosition(0);
            updateEmptyState();
        }
        HistoryNotification.cancel(this);
    }
}
