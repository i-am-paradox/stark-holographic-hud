package com.demo.privatewebbrowser.WebWIndowData;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Message;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.FrameLayout;
import androidx.core.view.ViewCompat;

public class SameWindowChrome extends WebChromeClient {
    private Activity activity;
    private View customView;
    private CustomViewCallback customViewCallback;
    private FrameLayout fullScreenContainer;

    public SameWindowChrome(Activity activity2, WebView webView) {
        this.activity = activity2;
    }

    @Override
    public void onShowCustomView(View view, CustomViewCallback customViewCallback2) {
        if (this.customView != null) {
            customViewCallback2.onCustomViewHidden();
            return;
        }
        FrameLayout frameLayout = new FrameLayout(this.activity);
        this.fullScreenContainer = frameLayout;
        frameLayout.setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        this.fullScreenContainer.addView(view, new FrameLayout.LayoutParams(-1, -1));
        ((FrameLayout) this.activity.getWindow().getDecorView()).addView(this.fullScreenContainer);
        this.customView = view;
        this.customViewCallback = customViewCallback2;
        this.activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }

    @Override
    public void onHideCustomView() {
        if (this.customView != null) {
            ((FrameLayout) this.activity.getWindow().getDecorView()).removeView(this.fullScreenContainer);
            this.fullScreenContainer = null;
            this.customView = null;
            this.customViewCallback.onCustomViewHidden();
            this.activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }

    @Override
    public boolean onCreateWindow(WebView webView, boolean z, boolean z2, Message message) {
        WebView.HitTestResult hitTestResult = webView.getHitTestResult();
        String extra = hitTestResult != null ? hitTestResult.getExtra() : null;
        if (extra == null) {
            return false;
        }
        webView.loadUrl(extra);
        return false;
    }

}
