package com.demo.privatewebbrowser.Model;

public class HistoryItem {
    public long time = System.currentTimeMillis();
    public String title;
    public String url;

    public HistoryItem(String str, String str2) {
        this.title = str;
        this.url = str2;
    }
}
