package com.demo.privatewebbrowser.Activity;

import com.demo.privatewebbrowser.Adapter.TabAdapter;


public final class TabOpenActivityOnCardClick implements TabAdapter.OnCardClick {
    public final TabOpenActivity act1;

    public TabOpenActivityOnCardClick(TabOpenActivity tabOpenActivity) {
        this.act1 = tabOpenActivity;
    }

    @Override
    public void select(int i) {
        this.act1.returnChoice(i);
    }
}
